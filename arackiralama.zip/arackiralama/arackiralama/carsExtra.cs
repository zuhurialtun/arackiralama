﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace arackiralama
{
    public partial class carsExtra : UserControl
    {
        public carsExtra()
        {
            InitializeComponent();
        }
        vtClass vt = new vtClass(false);
        private void carsExtra_Load(object sender, EventArgs e)
        {
            dataG_marka.DataSource = vt.verial("markaAd as Marka","markalar", "0", "0");
            dataG_model.DataSource = vt.verial("modeller.modelAd as Model,markalar.markaAd as Marka","modeller", "Inner Join markalar On markalar.markaID=modeller.modelMarka ORDER BY markalar.markaAd", "0");

            cb_marka.DataSource = vt.verial("*", "markalar", "0", "0");
            cb_marka.ValueMember = "markaID";
            cb_marka.DisplayMember = "markaAd";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (vt.veriekle("markalar",tb_marka.Text.ToString()))
            {
                MessageBox.Show("Kayıt Başarılı");
            }
            else
            {
                MessageBox.Show("Kayıt Yapılamadı");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (vt.veriekle("modeller", tb_model.Text.ToString(), cb_marka.SelectedValue))
            {
                MessageBox.Show("Kayıt Başarılı");
            }
            else
            {
                MessageBox.Show("Kayıt Yapılamadı");
            }
        }
    }
}
