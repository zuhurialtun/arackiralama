﻿namespace arackiralama
{
    partial class istatistik
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pnl_istMenu = new System.Windows.Forms.Panel();
            this.btn_usersInfo = new System.Windows.Forms.Button();
            this.btn_carsInfo = new System.Windows.Forms.Button();
            this.ist_Content = new System.Windows.Forms.Panel();
            this.btn_kiraAll = new System.Windows.Forms.Button();
            this.pnl_istMenu.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnl_istMenu
            // 
            this.pnl_istMenu.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(36)))), ((int)(((byte)(35)))));
            this.pnl_istMenu.Controls.Add(this.btn_kiraAll);
            this.pnl_istMenu.Controls.Add(this.btn_usersInfo);
            this.pnl_istMenu.Controls.Add(this.btn_carsInfo);
            this.pnl_istMenu.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnl_istMenu.Location = new System.Drawing.Point(0, 0);
            this.pnl_istMenu.Name = "pnl_istMenu";
            this.pnl_istMenu.Size = new System.Drawing.Size(1064, 50);
            this.pnl_istMenu.TabIndex = 0;
            // 
            // btn_usersInfo
            // 
            this.btn_usersInfo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(36)))), ((int)(((byte)(35)))));
            this.btn_usersInfo.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btn_usersInfo.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_usersInfo.Dock = System.Windows.Forms.DockStyle.Left;
            this.btn_usersInfo.FlatAppearance.BorderSize = 0;
            this.btn_usersInfo.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.btn_usersInfo.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.btn_usersInfo.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_usersInfo.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btn_usersInfo.ForeColor = System.Drawing.Color.White;
            this.btn_usersInfo.Location = new System.Drawing.Point(200, 0);
            this.btn_usersInfo.Name = "btn_usersInfo";
            this.btn_usersInfo.Size = new System.Drawing.Size(200, 50);
            this.btn_usersInfo.TabIndex = 5;
            this.btn_usersInfo.Text = "Müşteri İstatistikleri";
            this.btn_usersInfo.UseVisualStyleBackColor = false;
            this.btn_usersInfo.Click += new System.EventHandler(this.btn_usersInfo_Click);
            // 
            // btn_carsInfo
            // 
            this.btn_carsInfo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(36)))), ((int)(((byte)(35)))));
            this.btn_carsInfo.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btn_carsInfo.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_carsInfo.Dock = System.Windows.Forms.DockStyle.Left;
            this.btn_carsInfo.FlatAppearance.BorderSize = 0;
            this.btn_carsInfo.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.btn_carsInfo.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.btn_carsInfo.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_carsInfo.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btn_carsInfo.ForeColor = System.Drawing.Color.White;
            this.btn_carsInfo.Location = new System.Drawing.Point(0, 0);
            this.btn_carsInfo.Name = "btn_carsInfo";
            this.btn_carsInfo.Size = new System.Drawing.Size(200, 50);
            this.btn_carsInfo.TabIndex = 4;
            this.btn_carsInfo.Text = "Araç İstatistikleri";
            this.btn_carsInfo.UseVisualStyleBackColor = false;
            this.btn_carsInfo.Click += new System.EventHandler(this.btn_carsInfo_Click);
            // 
            // ist_Content
            // 
            this.ist_Content.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(237)))), ((int)(((byte)(223)))));
            this.ist_Content.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ist_Content.Location = new System.Drawing.Point(0, 50);
            this.ist_Content.Name = "ist_Content";
            this.ist_Content.Size = new System.Drawing.Size(1064, 531);
            this.ist_Content.TabIndex = 1;
            // 
            // btn_kiraAll
            // 
            this.btn_kiraAll.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(36)))), ((int)(((byte)(35)))));
            this.btn_kiraAll.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btn_kiraAll.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_kiraAll.Dock = System.Windows.Forms.DockStyle.Left;
            this.btn_kiraAll.FlatAppearance.BorderSize = 0;
            this.btn_kiraAll.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.btn_kiraAll.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.btn_kiraAll.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_kiraAll.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btn_kiraAll.ForeColor = System.Drawing.Color.White;
            this.btn_kiraAll.Location = new System.Drawing.Point(400, 0);
            this.btn_kiraAll.Name = "btn_kiraAll";
            this.btn_kiraAll.Size = new System.Drawing.Size(200, 50);
            this.btn_kiraAll.TabIndex = 6;
            this.btn_kiraAll.Text = "Kiralama Geçmişi";
            this.btn_kiraAll.UseVisualStyleBackColor = false;
            this.btn_kiraAll.Click += new System.EventHandler(this.btn_kiraAll_Click);
            // 
            // istatistik
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.ist_Content);
            this.Controls.Add(this.pnl_istMenu);
            this.Name = "istatistik";
            this.Size = new System.Drawing.Size(1064, 581);
            this.pnl_istMenu.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnl_istMenu;
        private System.Windows.Forms.Panel ist_Content;
        private System.Windows.Forms.Button btn_usersInfo;
        private System.Windows.Forms.Button btn_carsInfo;
        private System.Windows.Forms.Button btn_kiraAll;
    }
}
