﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace arackiralama
{
    public partial class userAdd : UserControl
    {
        public userAdd()
        {
            InitializeComponent();
        }
        vtClass vt = new vtClass(false);
        private void userAdd_Load(object sender, EventArgs e)
        {
            cb_cinsiyet.DisplayMember = "Text";
            cb_cinsiyet.ValueMember = "Value";
            var items = new[] {
                new { Text = "Kadın", Value = "1" },
                new { Text = "Erkek", Value = "0" }
            };
            cb_cinsiyet.DataSource = items;

            cb_ehliyettur.DisplayMember = "Text";
            cb_ehliyettur.ValueMember = "Value";
            var items2 = new[] {
                new { Text = "M", Value = "0" },
                new { Text = "A1", Value = "1" },
                new { Text = "A2", Value = "2" },
                new { Text = "A", Value = "3" },
                new { Text = "B1", Value = "4" },
                new { Text = "B", Value = "5" },
                new { Text = "BE", Value = "6" },
                new { Text = "C1", Value = "7" },
                new { Text = "C", Value = "8" },
                new { Text = "CE", Value = "9" },
                new { Text = "D1", Value = "10" },
                new { Text = "D", Value = "11" },
                new { Text = "DE", Value = "12" },
                new { Text = "F", Value = "13" },
                new { Text = "G", Value = "14" }
            };
            cb_ehliyettur.DataSource = items2;
        }

        private void btn_userAdd_Click(object sender, EventArgs e)
        {
            if (tb_tc.TextLength<11)
            {
                MessageBox.Show("TC kimlik numarası 11 haneden az olamaz");
            }
            else
            {
                if (int.Parse(vt.verial("Count(musteriTC)", "musteriler", "0", "musteriTC ='" + tb_tc.Text + "'").Rows[0][0].ToString()) > 0)
                {
                    MessageBox.Show("Bu müşteri sisteme kayıtlı!");
                }
                else
                {
                    if (vt.veriekle("musteriler", tb_tc.Text, tb_ad.Text, tb_soyad.Text, cb_cinsiyet.SelectedValue, dateTimePicker1.Value.Date.ToString("yyyy-MM-dd").ToString(), richTextBox1.Text, tb_mail.Text, tb_telno.Text, tb_ehliyetno.Text, cb_ehliyettur.Text))
                    {
                        MessageBox.Show("Müşteri Kaydı Başarılı.");
                    }
                    else
                    {
                        MessageBox.Show("Kayıt Yapılamadı!");
                    }
                }
            }
        }
    }
}
