﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace arackiralama
{
    public partial class userUpdate : UserControl
    {
        public userUpdate()
        {
            InitializeComponent();
        }
        vtClass vt = new vtClass(false);
        private void tb_tc_TextChanged(object sender, EventArgs e)
        {
            dataG_user.DataSource = vt.verial("musteriID as ID, musteriTC as TC, musteriAd as Ad, musteriSoyad as Soyad, musteriCinsiyet as Cinsiyet, musteriDogumTarihi as DoğumTarihi, musteriAdres as Adres, musteriMail as Mail, musteriPhone as Tel, musteriEhliyetNo as EhliyetNo, musteriEhliyetTur as EhliyetTürü","musteriler","0", ("musteriTC LIKE '%" + tb_tc.Text.ToString() + "%'"));
        }

        private void userUpdate_Load(object sender, EventArgs e)
        {
            cb_cinsiyet.DisplayMember = "Text";
            cb_cinsiyet.ValueMember = "Value";
            var items = new[] {
                new { Text = "Kadın", Value = "1" },
                new { Text = "Erkek", Value = "0" }
            };
            cb_cinsiyet.DataSource = items;

            cb_ehliyettur.DisplayMember = "Text";
            cb_ehliyettur.ValueMember = "Value";
            var items2 = new[] {
                new { Text = "M", Value = "0" },
                new { Text = "A1", Value = "1" },
                new { Text = "A2", Value = "2" },
                new { Text = "A", Value = "3" },
                new { Text = "B1", Value = "4" },
                new { Text = "B", Value = "5" },
                new { Text = "BE", Value = "6" },
                new { Text = "C1", Value = "7" },
                new { Text = "C", Value = "8" },
                new { Text = "CE", Value = "9" },
                new { Text = "D1", Value = "10" },
                new { Text = "D", Value = "11" },
                new { Text = "DE", Value = "12" },
                new { Text = "F", Value = "13" },
                new { Text = "G", Value = "14" }
            };
            cb_ehliyettur.DataSource = items2;
        }

        private void dataG_user_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            tb_tc.Text = dataG_user.CurrentRow.Cells[1].Value.ToString();
            tb_ad.Text = dataG_user.CurrentRow.Cells[2].Value.ToString();
            tb_soyad.Text = dataG_user.CurrentRow.Cells[3].Value.ToString();
            if (dataG_user.CurrentRow.Cells[4].Value.ToString()=="1")
            { cb_cinsiyet.SelectedIndex = 0;}
            else
            {cb_cinsiyet.SelectedIndex = 1;}
            dt_dogumT.Text = dataG_user.CurrentRow.Cells[5].Value.ToString();
            rtb_adres.Text = dataG_user.CurrentRow.Cells[6].Value.ToString();
            tb_mail.Text = dataG_user.CurrentRow.Cells[7].Value.ToString();
            tb_telno.Text = dataG_user.CurrentRow.Cells[8].Value.ToString();
            tb_ehliyetno.Text = dataG_user.CurrentRow.Cells[9].Value.ToString();
            cb_ehliyettur.Text = dataG_user.CurrentRow.Cells[10].Value.ToString();
        }

        private void btn_userUpdate_Click(object sender, EventArgs e)
        {
            vt.kayitGuncelle("musteriler","musteriTC",tb_tc.Text,tb_tc.Text,tb_ad.Text,tb_soyad.Text,cb_cinsiyet.SelectedValue,dt_dogumT.Value.Date.ToString("yyyy-MM-dd"),rtb_adres.Text,tb_mail.Text,tb_telno.Text,tb_ehliyetno.Text,cb_ehliyettur.Text);
        }
    }
}