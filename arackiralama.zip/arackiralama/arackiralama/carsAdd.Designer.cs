﻿namespace arackiralama
{
    partial class carsAdd
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.cb_model = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.tb_aracPlaka = new System.Windows.Forms.TextBox();
            this.tb_aracYil = new System.Windows.Forms.TextBox();
            this.cb_aracYakitTip = new System.Windows.Forms.ComboBox();
            this.cb_AracVitesTip = new System.Windows.Forms.ComboBox();
            this.cb_aracCekisTip = new System.Windows.Forms.ComboBox();
            this.cb_aracRenk = new System.Windows.Forms.ComboBox();
            this.cb_AracKlima = new System.Windows.Forms.ComboBox();
            this.cb_il = new System.Windows.Forms.ComboBox();
            this.tb_aracKm = new System.Windows.Forms.TextBox();
            this.tb_aracKisi = new System.Windows.Forms.TextBox();
            this.tb_aracUcret = new System.Windows.Forms.TextBox();
            this.rtb_aracAdres = new System.Windows.Forms.RichTextBox();
            this.btn_userAdd = new System.Windows.Forms.Button();
            this.label14 = new System.Windows.Forms.Label();
            this.cb_marka = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(36)))), ((int)(((byte)(35)))));
            this.label1.Location = new System.Drawing.Point(82, 23);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(92, 16);
            this.label1.TabIndex = 2;
            this.label1.Text = "Araç Plaka :";
            // 
            // cb_model
            // 
            this.cb_model.FormattingEnabled = true;
            this.cb_model.Location = new System.Drawing.Point(180, 76);
            this.cb_model.Name = "cb_model";
            this.cb_model.Size = new System.Drawing.Size(145, 21);
            this.cb_model.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(36)))), ((int)(((byte)(35)))));
            this.label2.Location = new System.Drawing.Point(79, 76);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(95, 16);
            this.label2.TabIndex = 4;
            this.label2.Text = "Araç Model :";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(36)))), ((int)(((byte)(35)))));
            this.label3.Location = new System.Drawing.Point(100, 107);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(74, 16);
            this.label3.TabIndex = 5;
            this.label3.Text = "Araç Yılı :";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(36)))), ((int)(((byte)(35)))));
            this.label4.Location = new System.Drawing.Point(56, 134);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(118, 16);
            this.label4.TabIndex = 6;
            this.label4.Text = "Araç Yakıt Tipi :";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(36)))), ((int)(((byte)(35)))));
            this.label5.Location = new System.Drawing.Point(56, 162);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(118, 16);
            this.label5.TabIndex = 7;
            this.label5.Text = "Araç Vites Tipi :";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(36)))), ((int)(((byte)(35)))));
            this.label6.Location = new System.Drawing.Point(101, 188);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(73, 16);
            this.label6.TabIndex = 8;
            this.label6.Text = "Araç Km :";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(36)))), ((int)(((byte)(35)))));
            this.label7.Location = new System.Drawing.Point(52, 215);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(122, 16);
            this.label7.TabIndex = 9;
            this.label7.Text = "Araç Çekiş Tipi :";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(36)))), ((int)(((byte)(35)))));
            this.label8.Location = new System.Drawing.Point(20, 241);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(154, 16);
            this.label8.TabIndex = 10;
            this.label8.Text = "Araç Kişi Kapasitesi :";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label9.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(36)))), ((int)(((byte)(35)))));
            this.label9.Location = new System.Drawing.Point(81, 271);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(93, 16);
            this.label9.TabIndex = 11;
            this.label9.Text = "Araç Rengi :";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label10.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(36)))), ((int)(((byte)(35)))));
            this.label10.Location = new System.Drawing.Point(84, 298);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(90, 16);
            this.label10.TabIndex = 12;
            this.label10.Text = "Araç Klima :";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label11.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(36)))), ((int)(((byte)(35)))));
            this.label11.Location = new System.Drawing.Point(114, 325);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(60, 16);
            this.label11.TabIndex = 13;
            this.label11.Text = "Araç İl :";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label12.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(36)))), ((int)(((byte)(35)))));
            this.label12.Location = new System.Drawing.Point(349, 23);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(97, 16);
            this.label12.TabIndex = 14;
            this.label12.Text = "Araç Adresi :";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label13.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(36)))), ((int)(((byte)(35)))));
            this.label13.Location = new System.Drawing.Point(50, 351);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(124, 16);
            this.label13.TabIndex = 15;
            this.label13.Text = "Araç Kira Ücreti :";
            // 
            // tb_aracPlaka
            // 
            this.tb_aracPlaka.Location = new System.Drawing.Point(180, 23);
            this.tb_aracPlaka.MaxLength = 8;
            this.tb_aracPlaka.Name = "tb_aracPlaka";
            this.tb_aracPlaka.Size = new System.Drawing.Size(145, 20);
            this.tb_aracPlaka.TabIndex = 16;
            // 
            // tb_aracYil
            // 
            this.tb_aracYil.Location = new System.Drawing.Point(180, 103);
            this.tb_aracYil.MaxLength = 4;
            this.tb_aracYil.Name = "tb_aracYil";
            this.tb_aracYil.Size = new System.Drawing.Size(145, 20);
            this.tb_aracYil.TabIndex = 17;
            // 
            // cb_aracYakitTip
            // 
            this.cb_aracYakitTip.FormattingEnabled = true;
            this.cb_aracYakitTip.Location = new System.Drawing.Point(180, 129);
            this.cb_aracYakitTip.Name = "cb_aracYakitTip";
            this.cb_aracYakitTip.Size = new System.Drawing.Size(145, 21);
            this.cb_aracYakitTip.TabIndex = 18;
            // 
            // cb_AracVitesTip
            // 
            this.cb_AracVitesTip.FormattingEnabled = true;
            this.cb_AracVitesTip.Location = new System.Drawing.Point(180, 157);
            this.cb_AracVitesTip.Name = "cb_AracVitesTip";
            this.cb_AracVitesTip.Size = new System.Drawing.Size(145, 21);
            this.cb_AracVitesTip.TabIndex = 19;
            // 
            // cb_aracCekisTip
            // 
            this.cb_aracCekisTip.FormattingEnabled = true;
            this.cb_aracCekisTip.Location = new System.Drawing.Point(180, 210);
            this.cb_aracCekisTip.Name = "cb_aracCekisTip";
            this.cb_aracCekisTip.Size = new System.Drawing.Size(145, 21);
            this.cb_aracCekisTip.TabIndex = 20;
            // 
            // cb_aracRenk
            // 
            this.cb_aracRenk.FormattingEnabled = true;
            this.cb_aracRenk.Location = new System.Drawing.Point(180, 266);
            this.cb_aracRenk.Name = "cb_aracRenk";
            this.cb_aracRenk.Size = new System.Drawing.Size(145, 21);
            this.cb_aracRenk.TabIndex = 21;
            // 
            // cb_AracKlima
            // 
            this.cb_AracKlima.FormattingEnabled = true;
            this.cb_AracKlima.Location = new System.Drawing.Point(179, 293);
            this.cb_AracKlima.Name = "cb_AracKlima";
            this.cb_AracKlima.Size = new System.Drawing.Size(145, 21);
            this.cb_AracKlima.TabIndex = 22;
            // 
            // cb_il
            // 
            this.cb_il.FormattingEnabled = true;
            this.cb_il.Location = new System.Drawing.Point(179, 320);
            this.cb_il.Name = "cb_il";
            this.cb_il.Size = new System.Drawing.Size(145, 21);
            this.cb_il.TabIndex = 23;
            // 
            // tb_aracKm
            // 
            this.tb_aracKm.Location = new System.Drawing.Point(180, 184);
            this.tb_aracKm.MaxLength = 7;
            this.tb_aracKm.Name = "tb_aracKm";
            this.tb_aracKm.Size = new System.Drawing.Size(145, 20);
            this.tb_aracKm.TabIndex = 24;
            // 
            // tb_aracKisi
            // 
            this.tb_aracKisi.Location = new System.Drawing.Point(180, 237);
            this.tb_aracKisi.MaxLength = 3;
            this.tb_aracKisi.Name = "tb_aracKisi";
            this.tb_aracKisi.Size = new System.Drawing.Size(145, 20);
            this.tb_aracKisi.TabIndex = 25;
            // 
            // tb_aracUcret
            // 
            this.tb_aracUcret.Location = new System.Drawing.Point(179, 347);
            this.tb_aracUcret.MaxLength = 5;
            this.tb_aracUcret.Name = "tb_aracUcret";
            this.tb_aracUcret.Size = new System.Drawing.Size(145, 20);
            this.tb_aracUcret.TabIndex = 26;
            // 
            // rtb_aracAdres
            // 
            this.rtb_aracAdres.Location = new System.Drawing.Point(352, 43);
            this.rtb_aracAdres.Name = "rtb_aracAdres";
            this.rtb_aracAdres.Size = new System.Drawing.Size(268, 142);
            this.rtb_aracAdres.TabIndex = 27;
            this.rtb_aracAdres.Text = "";
            // 
            // btn_userAdd
            // 
            this.btn_userAdd.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(207)))), ((int)(((byte)(219)))), ((int)(((byte)(213)))));
            this.btn_userAdd.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_userAdd.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(36)))), ((int)(((byte)(35)))));
            this.btn_userAdd.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_userAdd.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btn_userAdd.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(36)))), ((int)(((byte)(35)))));
            this.btn_userAdd.Location = new System.Drawing.Point(352, 199);
            this.btn_userAdd.Name = "btn_userAdd";
            this.btn_userAdd.Size = new System.Drawing.Size(268, 50);
            this.btn_userAdd.TabIndex = 30;
            this.btn_userAdd.Text = "Kayıt Et";
            this.btn_userAdd.UseVisualStyleBackColor = false;
            this.btn_userAdd.Click += new System.EventHandler(this.btn_userAdd_Click);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label14.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(36)))), ((int)(((byte)(35)))));
            this.label14.Location = new System.Drawing.Point(79, 49);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(95, 16);
            this.label14.TabIndex = 32;
            this.label14.Text = "Araç Marka :";
            // 
            // cb_marka
            // 
            this.cb_marka.FormattingEnabled = true;
            this.cb_marka.Location = new System.Drawing.Point(180, 49);
            this.cb_marka.Name = "cb_marka";
            this.cb_marka.Size = new System.Drawing.Size(145, 21);
            this.cb_marka.TabIndex = 31;
            this.cb_marka.SelectedIndexChanged += new System.EventHandler(this.cb_marka_SelectedIndexChanged);
            // 
            // carsAdd
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(237)))), ((int)(((byte)(223)))));
            this.Controls.Add(this.label14);
            this.Controls.Add(this.cb_marka);
            this.Controls.Add(this.btn_userAdd);
            this.Controls.Add(this.rtb_aracAdres);
            this.Controls.Add(this.tb_aracUcret);
            this.Controls.Add(this.tb_aracKisi);
            this.Controls.Add(this.tb_aracKm);
            this.Controls.Add(this.cb_il);
            this.Controls.Add(this.cb_AracKlima);
            this.Controls.Add(this.cb_aracRenk);
            this.Controls.Add(this.cb_aracCekisTip);
            this.Controls.Add(this.cb_AracVitesTip);
            this.Controls.Add(this.cb_aracYakitTip);
            this.Controls.Add(this.tb_aracYil);
            this.Controls.Add(this.tb_aracPlaka);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.cb_model);
            this.Controls.Add(this.label1);
            this.Name = "carsAdd";
            this.Size = new System.Drawing.Size(664, 531);
            this.Load += new System.EventHandler(this.carsAdd_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cb_model;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox tb_aracPlaka;
        private System.Windows.Forms.TextBox tb_aracYil;
        private System.Windows.Forms.ComboBox cb_aracYakitTip;
        private System.Windows.Forms.ComboBox cb_AracVitesTip;
        private System.Windows.Forms.ComboBox cb_aracCekisTip;
        private System.Windows.Forms.ComboBox cb_aracRenk;
        private System.Windows.Forms.ComboBox cb_AracKlima;
        private System.Windows.Forms.ComboBox cb_il;
        private System.Windows.Forms.TextBox tb_aracKm;
        private System.Windows.Forms.TextBox tb_aracKisi;
        private System.Windows.Forms.TextBox tb_aracUcret;
        private System.Windows.Forms.RichTextBox rtb_aracAdres;
        private System.Windows.Forms.Button btn_userAdd;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.ComboBox cb_marka;
    }
}
