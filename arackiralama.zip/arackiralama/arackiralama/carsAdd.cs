﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace arackiralama
{
    public partial class carsAdd : UserControl
    {
        public carsAdd()
        {
            InitializeComponent();
        }
        vtClass vt = new vtClass(false);
        private void carsAdd_Load(object sender, EventArgs e)
        {
            cb_marka.DataSource = vt.verial("*", "markalar", "", "markaID IN (Select modelMarka from modeller) ORDER BY markaAd");
            cb_marka.ValueMember = "markaID";
            cb_marka.DisplayMember = "markaAd";

            cb_model.DataSource = vt.verial("*", "modeller", "0", ("modelMarka LIKE '" + cb_marka.SelectedValue.ToString() + "'" + " ORDER BY modelAd"));
            cb_model.ValueMember = "modelID";
            cb_model.DisplayMember = "modelAd";

            cb_aracYakitTip.DataSource=vt.verial("*","yakıttip", "0", "0");
            cb_aracYakitTip.ValueMember = "yakıttipID";
            cb_aracYakitTip.DisplayMember = "yakıttipAd";

            cb_AracVitesTip.DataSource = vt.verial("*", "vites", "0", "0");
            cb_AracVitesTip.ValueMember = "vitesID";
            cb_AracVitesTip.DisplayMember = "vitesAd";

            cb_aracCekisTip.DataSource = vt.verial("*", "cekis", "0", "0");
            cb_aracCekisTip.ValueMember = "cekisID";
            cb_aracCekisTip.DisplayMember = "cekisAd";

            cb_aracRenk.DataSource = vt.verial("*", "renk", "0", "0");
            cb_aracRenk.ValueMember = "renkID";
            cb_aracRenk.DisplayMember = "renkAd";

            cb_AracKlima.DisplayMember = "Text";
            cb_AracKlima.ValueMember = "Value";
            var items = new[] {
                new { Text = "var", Value = "1" },
                new { Text = "yok", Value = "0" }
            };
            cb_AracKlima.DataSource = items;

            cb_il.DataSource = vt.verial("*","iller", "0", "0");
            cb_il.ValueMember = "ilID";
            cb_il.DisplayMember = "ilAd";
        }

        private void btn_userAdd_Click(object sender, EventArgs e)
        {
            if (tb_aracPlaka.TextLength<8)
            {
                MessageBox.Show("Araç Plakası en az 8 hane olmalıdır!");
            }
            else
            {
                if (int.Parse(vt.verial("Count(aracPlaka)", "araclar", "0", "aracPlaka ='" + tb_aracPlaka.Text + "'").Rows[0][0].ToString()) > 0)
                {
                    MessageBox.Show("Bu araç zaten sisteme kayıtlı!");
                }
                else
                {
                    if (vt.veriekle("araclar", tb_aracPlaka.Text.ToString(), cb_model.SelectedValue, tb_aracYil.Text.ToString(), cb_aracYakitTip.SelectedValue, cb_AracVitesTip.SelectedValue, tb_aracKm.Text.ToString(), cb_aracCekisTip.SelectedValue, tb_aracKisi.Text.ToString(), cb_aracRenk.SelectedValue, cb_AracKlima.SelectedValue.ToString(), cb_il.SelectedValue, rtb_aracAdres.Text.ToString(), tb_aracUcret.Text.ToString(), 0))
                    {
                        MessageBox.Show("Kayıt Başarılı");
                    }
                    else
                    {
                        MessageBox.Show("Kayıt Yapılamadı");
                    }
                }
            }
        }

        private void cb_marka_SelectedIndexChanged(object sender, EventArgs e)
        {
            cb_model.DataSource = vt.verial("*", "modeller", "0", ("modelMarka LIKE '" + cb_marka.SelectedValue.ToString() +"'"));
            cb_model.ValueMember = "modelID";
            cb_model.DisplayMember = "modelAd";
        }
    }
}
