﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace arackiralama
{
    public partial class cars : UserControl
    {
        public cars()
        {
            InitializeComponent();
        }
        vtClass vt = new vtClass(false);
        public void showControl(Control control)
        {
            cars_Content.Controls.Clear();
            control.Dock = DockStyle.Fill;
            control.BringToFront();
            control.Focus();
            cars_Content.Controls.Add(control);
        }

        private void btn_carsList_Click(object sender, EventArgs e)
        {
            data_cars.DataSource= vt.verial("araclar.aracPlaka as Plaka,markalar.markaAd as Marka, modeller.modelAd as Model", "araclar", "INNER JOIN modeller ON araclar.modelID = modeller.modelID INNER JOIN markalar ON modeller.modelMarka=markalar.markaID","0");
        }

        private void btn_carsAdd_Click(object sender, EventArgs e)
        {
            carsAdd caA = new carsAdd();
            showControl(caA);
        }

        private void btn_carsUpdate_Click(object sender, EventArgs e)
        {
            carsUpdate caU = new carsUpdate();
            showControl(caU);
        }

        private void btn_carsDelete_Click(object sender, EventArgs e)
        {
            carsDelete caD = new carsDelete();
            showControl(caD);
        }

        private void btn_carsExtra_Click(object sender, EventArgs e)
        {
            carsExtra caE = new carsExtra();
            showControl(caE);
        }

        private void tb_carSearch_TextChanged(object sender, EventArgs e)
        {
            data_cars.DataSource = vt.verial("araclar.aracPlaka as Plaka,markalar.markaAd as Marka, modeller.modelAd as Model","araclar", "INNER JOIN modeller ON araclar.modelID = modeller.modelID INNER JOIN markalar ON modeller.modelMarka=markalar.markaID",("araclar.aracPlaka LIKE '%"+tb_carSearch.Text+"%'"));
        }
    }
}
