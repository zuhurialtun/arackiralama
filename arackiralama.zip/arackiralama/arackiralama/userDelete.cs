﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace arackiralama
{
    public partial class userDelete : UserControl
    {
        public userDelete()
        {
            InitializeComponent();
        }
        vtClass vt = new vtClass(false);
        private void btn_userDelete_Click(object sender, EventArgs e)
        {
            vt.verisil("musteriler", "musteriTC", cb_musteriTc.Text);
            cb_musteriTc.DataSource = vt.verial("*", "musteriler", "0", "0");
            cb_musteriTc.ValueMember = "musteriID";
            cb_musteriTc.DisplayMember = "musteriTC";

        }

        private void userDelete_Load(object sender, EventArgs e)
        {
            cb_musteriTc.DataSource = vt.verial("*", "musteriler", "0", "0");
            cb_musteriTc.ValueMember = "musteriID";
            cb_musteriTc.DisplayMember = "musteriTC";
        }
    }
}
