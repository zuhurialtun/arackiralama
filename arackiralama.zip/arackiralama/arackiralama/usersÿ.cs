﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace arackiralama
{
    public partial class usersİ : UserControl
    {
        public usersİ()
        {
            InitializeComponent();
        }
        vtClass vt = new vtClass(false);
        private void timer1_Tick(object sender, EventArgs e)
        {
            lbl_erkek.Text = vt.verial("Count(*)", "musteriler", "0", "musteriCinsiyet='0'").Rows[0][0].ToString() + " Erkek Müşteri";
            lbl_kadin.Text = vt.verial("Count(*)", "musteriler", "0", "musteriCinsiyet='1'").Rows[0][0].ToString() + " Kadın Müşteri";
            lbl_erkekMoney.Text = vt.verial("SUM(kiralama.kiraUcret)", "kiralama", "INNER JOIN musteriler ON musteriler.musteriID=kiralama.kiraMusteriID", "musteriler.musteriCinsiyet='0'").Rows[0][0].ToString() + " TL";
            lbl_kadinMoney.Text = vt.verial("SUM(kiralama.kiraUcret)", "kiralama", "INNER JOIN musteriler ON musteriler.musteriID=kiralama.kiraMusteriID", "musteriler.musteriCinsiyet='1'").Rows[0][0].ToString() + " TL";
        }
    }
}
