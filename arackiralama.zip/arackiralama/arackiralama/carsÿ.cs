﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;

namespace arackiralama
{
    public partial class carsİ : UserControl
    {
        public carsİ()
        {
            InitializeComponent();
        }
        vtClass vt = new vtClass(false);
        private void timer1_Tick(object sender, EventArgs e)
        {
            lbl_carsCount.Text = vt.verial("Count(*)", "araclar", "0", "0").Rows[0][0].ToString() + " araç";

            lbl_carsKiraT.Text = vt.verial("Count(*)", "araclar", "0", "aracKiraDurum=1").Rows[0][0].ToString() + " araç";

            lbl_carsKiraF.Text = vt.verial("Count(*)", "araclar", "0", "aracKiraDurum=0").Rows[0][0].ToString() + " araç";

            lbl_carsDay.Text = vt.verial("SUM(kiraUcret)", "kiralama", "0", "kiraGirisTarih = '"+ DateTime.Today.ToString("yyyy-MM-dd") + "'").Rows[0][0].ToString() + " TL";

            lbl_carsMonth.Text = vt.verial("SUM(kiraUcret)", "kiralama", "0", "kiraGirisTarih >= '"+(DateTime.Now.Year.ToString() + "-" + DateTime.Now.Month.ToString() + "-1")+"'").Rows[0][0].ToString() + " TL";

            lbl_carsYear.Text = vt.verial("SUM(kiraUcret)", "kiralama", "0", "kiraGirisTarih > '"+(DateTime.Now.Year.ToString()+"-1-1")+"'").Rows[0][0].ToString() + " TL";

            lbl_carsLast.Text = vt.verial("(musteriler.musteriAd +' '+ musteriler.musteriSoyad +' / '+ araclar.aracPlaka +' / '+ CONVERT(varchar(8), kiralama.kiraUcret) +' TL') as Adsoyad", "kiralama", "INNER JOIN musteriler ON musteriler.musteriID=kiralama.kiraMusteriID INNER JOIN araclar ON araclar.aracID=kiralama.kiraAracID ORDER BY kiralama.kiraID DESC", "0").Rows[0][0].ToString();

            cars_grafik.DataSource = vt.verial("distinct markalar.markaAd,(((Select Count(*) FROM modeller WHERE modeller.modelMarka=markalar.markaID)*100)/(select Count(*) FROM modeller)) as yuzde", "markalar", "INNER JOIN modeller ON modeller.modelMarka = markalar.markaID", "0");
            cars_grafik.Series[0].XValueMember = "markaAd";
            cars_grafik.Series[0].YValueMembers = "yuzde";
            cars_grafik.Series[0].Name = "Grafik";
            cars_grafik.Series[0].ChartType = SeriesChartType.Pie;//grafik şeklini değiştirir.
            cars_grafik.DataBind();
        }
    }
}
