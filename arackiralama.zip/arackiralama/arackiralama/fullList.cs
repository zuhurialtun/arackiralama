﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace arackiralama
{
    public partial class fullList : UserControl
    {
        public fullList(DataTable data)
        {
            InitializeComponent();
            data_list.DataSource = data;
        }
    }
}
