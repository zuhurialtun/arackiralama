﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace arackiralama
{
    public partial class carsUpdate : UserControl
    {
        public carsUpdate()
        {
            InitializeComponent();
        }
        vtClass vt = new vtClass(false);

        private void btn_userUpdate_Click(object sender, EventArgs e)
        {
            vt.kayitGuncelle("araclar","aracPlaka",tb_aracPlaka.Text.ToString(),tb_aracPlaka.Text.ToString(),cb_model.SelectedValue.ToString(),tb_aracYil.Text.ToString(),cb_aracYakitTip.SelectedValue.ToString(),cb_AracVitesTip.SelectedValue.ToString(),tb_aracKm.Text.ToString(),cb_aracCekisTip.SelectedValue.ToString(),tb_aracKisi.Text.ToString(),cb_aracRenk.SelectedValue.ToString(),cb_AracKlima.SelectedValue.ToString(),cb_il.SelectedValue.ToString(),rtb_aracAdres.Text.ToString(),tb_aracKira.Text.ToString(),0);
        }

        private void carsUpdate_Load(object sender, EventArgs e)
        {
            cb_marka.DataSource = vt.verial("*", "markalar", "0", "0");
            cb_marka.ValueMember = "markaID";
            cb_marka.DisplayMember = "markaAd";

            cb_model.DataSource = vt.verial("*", "modeller", "0", ("modelMarka LIKE '" + cb_marka.SelectedValue.ToString() + "'"));
            cb_model.ValueMember = "modelID";
            cb_model.DisplayMember = "modelAd";

            cb_aracYakitTip.DataSource = vt.verial("*", "yakıttip", "0", "0");
            cb_aracYakitTip.ValueMember = "yakıttipID";
            cb_aracYakitTip.DisplayMember = "yakıttipAd";

            cb_AracVitesTip.DataSource = vt.verial("*", "vites", "0", "0");
            cb_AracVitesTip.ValueMember = "vitesID";
            cb_AracVitesTip.DisplayMember = "vitesAd";

            cb_aracCekisTip.DataSource = vt.verial("*", "cekis", "0", "0");
            cb_aracCekisTip.ValueMember = "cekisID";
            cb_aracCekisTip.DisplayMember = "cekisAd";

            cb_aracRenk.DataSource = vt.verial("*", "renk", "0", "0");
            cb_aracRenk.ValueMember = "renkID";
            cb_aracRenk.DisplayMember = "renkAd";

            cb_AracKlima.DisplayMember = "Text";
            cb_AracKlima.ValueMember = "Value";
            var items = new[] {
                new { Text = "var", Value = "1" },
                new { Text = "yok", Value = "0" }
            };
            cb_AracKlima.DataSource = items;

            cb_il.DataSource = vt.verial("*", "iller", "0", "0");
            cb_il.ValueMember = "ilID";
            cb_il.DisplayMember = "ilAd";
        }

        private void cb_marka_SelectedIndexChanged(object sender, EventArgs e)
        {
            cb_model.DataSource = vt.verial("*", "modeller", "0", ("modelMarka LIKE '" + cb_marka.SelectedValue.ToString() + "'"));
            cb_model.ValueMember = "modelID";
            cb_model.DisplayMember = "modelAd";
        }

        private void tb_aracPlaka_TextChanged(object sender, EventArgs e)
        {
            dataG_car.DataSource = vt.verial("araclar.aracPlaka,markalar.markaAd,modeller.modelAd,araclar.aracYil,yakıttip.yakıttipAd,vites.vitesAd,araclar.aracKm,cekis.cekisAd,araclar.aracKisi,renk.renkAd,araclar.aracKlima,iller.ilAd,araclar.aracKiraUcret,araclar.aracAdres", "araclar", "INNER JOIN modeller ON modeller.modelID=araclar.modelID INNER JOIN markalar ON markalar.markaID = modeller.modelMarka INNER JOIN yakıttip ON yakıttip.yakıttipID=araclar.yakıttipID INNER JOIN vites ON vites.vitesID=araclar.vitesID INNER JOIN cekis ON cekis.cekisID=araclar.cekisID INNER JOIN renk ON renk.renkID=araclar.renkID INNER JOIN iller ON iller.ilID=araclar.ilID", ("aracPlaka LIKE '%" + tb_aracPlaka.Text.ToString() + "%'"));
        }

        private void dataG_car_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            tb_aracPlaka.Text = dataG_car.CurrentRow.Cells[0].Value.ToString();
            cb_marka.Text = dataG_car.CurrentRow.Cells[1].Value.ToString();
            cb_model.Text = dataG_car.CurrentRow.Cells[2].Value.ToString();
            tb_aracYil.Text = dataG_car.CurrentRow.Cells[3].Value.ToString();
            cb_aracYakitTip.Text = dataG_car.CurrentRow.Cells[4].Value.ToString();
            cb_AracVitesTip.Text = dataG_car.CurrentRow.Cells[5].Value.ToString();
            tb_aracKm.Text = dataG_car.CurrentRow.Cells[6].Value.ToString();
            cb_aracCekisTip.Text = dataG_car.CurrentRow.Cells[7].Value.ToString();
            tb_aracKisi.Text = dataG_car.CurrentRow.Cells[8].Value.ToString();
            cb_aracRenk.Text = dataG_car.CurrentRow.Cells[9].Value.ToString();

            if (int.Parse(dataG_car.CurrentRow.Cells[10].Value.ToString())==1)
            {cb_AracKlima.SelectedIndex = 1;}
            else {cb_AracKlima.SelectedIndex = 1;}
            
            cb_il.Text = dataG_car.CurrentRow.Cells[11].Value.ToString();
            tb_aracKira.Text = dataG_car.CurrentRow.Cells[12].Value.ToString();
            rtb_aracAdres.Text = dataG_car.CurrentRow.Cells[13].Value.ToString();
        }
    }
}
