﻿namespace arackiralama
{
    partial class home
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pnl_homeMenu = new System.Windows.Forms.Panel();
            this.bttn_musteriList = new System.Windows.Forms.Button();
            this.btn_araclarList = new System.Windows.Forms.Button();
            this.btn_carsGive = new System.Windows.Forms.Button();
            this.btn_carsUsing = new System.Windows.Forms.Button();
            this.btn_home = new System.Windows.Forms.Button();
            this.home_Content = new System.Windows.Forms.Panel();
            this.pnl_homeMenu.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnl_homeMenu
            // 
            this.pnl_homeMenu.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(36)))), ((int)(((byte)(35)))));
            this.pnl_homeMenu.Controls.Add(this.bttn_musteriList);
            this.pnl_homeMenu.Controls.Add(this.btn_araclarList);
            this.pnl_homeMenu.Controls.Add(this.btn_carsGive);
            this.pnl_homeMenu.Controls.Add(this.btn_carsUsing);
            this.pnl_homeMenu.Controls.Add(this.btn_home);
            this.pnl_homeMenu.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnl_homeMenu.Location = new System.Drawing.Point(0, 0);
            this.pnl_homeMenu.Name = "pnl_homeMenu";
            this.pnl_homeMenu.Size = new System.Drawing.Size(1064, 50);
            this.pnl_homeMenu.TabIndex = 0;
            // 
            // bttn_musteriList
            // 
            this.bttn_musteriList.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(36)))), ((int)(((byte)(35)))));
            this.bttn_musteriList.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.bttn_musteriList.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bttn_musteriList.Dock = System.Windows.Forms.DockStyle.Left;
            this.bttn_musteriList.FlatAppearance.BorderSize = 0;
            this.bttn_musteriList.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(53)))), ((int)(((byte)(51)))));
            this.bttn_musteriList.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(53)))), ((int)(((byte)(51)))));
            this.bttn_musteriList.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bttn_musteriList.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.bttn_musteriList.ForeColor = System.Drawing.Color.White;
            this.bttn_musteriList.Location = new System.Drawing.Point(800, 0);
            this.bttn_musteriList.Name = "bttn_musteriList";
            this.bttn_musteriList.Size = new System.Drawing.Size(200, 50);
            this.bttn_musteriList.TabIndex = 6;
            this.bttn_musteriList.Text = "Müşteriler Tam Liste";
            this.bttn_musteriList.UseVisualStyleBackColor = false;
            this.bttn_musteriList.Click += new System.EventHandler(this.bttn_musteriList_Click);
            // 
            // btn_araclarList
            // 
            this.btn_araclarList.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(36)))), ((int)(((byte)(35)))));
            this.btn_araclarList.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btn_araclarList.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_araclarList.Dock = System.Windows.Forms.DockStyle.Left;
            this.btn_araclarList.FlatAppearance.BorderSize = 0;
            this.btn_araclarList.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(53)))), ((int)(((byte)(51)))));
            this.btn_araclarList.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(53)))), ((int)(((byte)(51)))));
            this.btn_araclarList.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_araclarList.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btn_araclarList.ForeColor = System.Drawing.Color.White;
            this.btn_araclarList.Location = new System.Drawing.Point(600, 0);
            this.btn_araclarList.Name = "btn_araclarList";
            this.btn_araclarList.Size = new System.Drawing.Size(200, 50);
            this.btn_araclarList.TabIndex = 5;
            this.btn_araclarList.Text = "Araçlar Tam Liste";
            this.btn_araclarList.UseVisualStyleBackColor = false;
            this.btn_araclarList.Click += new System.EventHandler(this.btn_araclarList_Click);
            // 
            // btn_carsGive
            // 
            this.btn_carsGive.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(36)))), ((int)(((byte)(35)))));
            this.btn_carsGive.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btn_carsGive.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_carsGive.Dock = System.Windows.Forms.DockStyle.Left;
            this.btn_carsGive.FlatAppearance.BorderSize = 0;
            this.btn_carsGive.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(53)))), ((int)(((byte)(51)))));
            this.btn_carsGive.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(53)))), ((int)(((byte)(51)))));
            this.btn_carsGive.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_carsGive.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btn_carsGive.ForeColor = System.Drawing.Color.White;
            this.btn_carsGive.Location = new System.Drawing.Point(400, 0);
            this.btn_carsGive.Name = "btn_carsGive";
            this.btn_carsGive.Size = new System.Drawing.Size(200, 50);
            this.btn_carsGive.TabIndex = 4;
            this.btn_carsGive.Text = "Araç Kirala";
            this.btn_carsGive.UseVisualStyleBackColor = false;
            this.btn_carsGive.Click += new System.EventHandler(this.btn_carsGive_Click);
            // 
            // btn_carsUsing
            // 
            this.btn_carsUsing.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(36)))), ((int)(((byte)(35)))));
            this.btn_carsUsing.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btn_carsUsing.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_carsUsing.Dock = System.Windows.Forms.DockStyle.Left;
            this.btn_carsUsing.FlatAppearance.BorderSize = 0;
            this.btn_carsUsing.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(53)))), ((int)(((byte)(51)))));
            this.btn_carsUsing.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(53)))), ((int)(((byte)(51)))));
            this.btn_carsUsing.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_carsUsing.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btn_carsUsing.ForeColor = System.Drawing.Color.White;
            this.btn_carsUsing.Location = new System.Drawing.Point(200, 0);
            this.btn_carsUsing.Name = "btn_carsUsing";
            this.btn_carsUsing.Size = new System.Drawing.Size(200, 50);
            this.btn_carsUsing.TabIndex = 3;
            this.btn_carsUsing.Text = "Kiradaki Araçlar";
            this.btn_carsUsing.UseVisualStyleBackColor = false;
            this.btn_carsUsing.Click += new System.EventHandler(this.btn_carsUsing_Click);
            // 
            // btn_home
            // 
            this.btn_home.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(36)))), ((int)(((byte)(35)))));
            this.btn_home.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btn_home.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_home.Dock = System.Windows.Forms.DockStyle.Left;
            this.btn_home.FlatAppearance.BorderSize = 0;
            this.btn_home.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(53)))), ((int)(((byte)(51)))));
            this.btn_home.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(53)))), ((int)(((byte)(51)))));
            this.btn_home.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_home.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btn_home.ForeColor = System.Drawing.Color.White;
            this.btn_home.Location = new System.Drawing.Point(0, 0);
            this.btn_home.Name = "btn_home";
            this.btn_home.Size = new System.Drawing.Size(200, 50);
            this.btn_home.TabIndex = 2;
            this.btn_home.Text = "Ana Sayfa";
            this.btn_home.UseVisualStyleBackColor = false;
            this.btn_home.Click += new System.EventHandler(this.btn_home_Click);
            // 
            // home_Content
            // 
            this.home_Content.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(237)))), ((int)(((byte)(223)))));
            this.home_Content.Dock = System.Windows.Forms.DockStyle.Fill;
            this.home_Content.Location = new System.Drawing.Point(0, 50);
            this.home_Content.Name = "home_Content";
            this.home_Content.Size = new System.Drawing.Size(1064, 531);
            this.home_Content.TabIndex = 1;
            // 
            // home
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.home_Content);
            this.Controls.Add(this.pnl_homeMenu);
            this.Name = "home";
            this.Size = new System.Drawing.Size(1064, 581);
            this.pnl_homeMenu.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnl_homeMenu;
        private System.Windows.Forms.Panel home_Content;
        private System.Windows.Forms.Button btn_araclarList;
        private System.Windows.Forms.Button btn_carsGive;
        private System.Windows.Forms.Button btn_carsUsing;
        private System.Windows.Forms.Button btn_home;
        private System.Windows.Forms.Button bttn_musteriList;
    }
}
