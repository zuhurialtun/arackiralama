﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace arackiralama
{
    public partial class Anasayfa : Form
    {
        public Anasayfa()
        {
            InitializeComponent();
        }
        public void showControl(Control control)
        {
            Content.Controls.Clear();
            control.Dock = DockStyle.Fill;
            control.BringToFront();
            control.Focus();
            Content.Controls.Add(control);
        }

        private void btn_home_Click(object sender, EventArgs e)
        {
            home hm = new home();
            showControl(hm);
        }

        private void btn_cars_Click(object sender, EventArgs e)
        {
            cars cr = new cars();
            showControl(cr);
        }

        private void btn_users_Click(object sender, EventArgs e)
        {
            users us = new users();
            showControl(us);
        }

        private void btn_istatistik_Click(object sender, EventArgs e)
        {
            istatistik ist = new istatistik();
            showControl(ist);
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            home hm = new home();
            showControl(hm);
        }

        private void btn_sigorta_Click(object sender, EventArgs e)
        {
            sigorta si = new sigorta();
            showControl(si);
        }
    }
}
