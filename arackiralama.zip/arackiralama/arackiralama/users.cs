﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;

namespace arackiralama
{
    public partial class users : UserControl
    {
        public users()
        {
            InitializeComponent();
        }
        vtClass vt = new vtClass(false);
        public void showControl(Control control)
        {
            users_Content.Controls.Clear();
            control.Dock = DockStyle.Fill;
            control.BringToFront();
            control.Focus();
            users_Content.Controls.Add(control);
        }
        
        private void btn_usersList_Click(object sender, EventArgs e)
        {
            data_users.DataSource = vt.verial("musteriTc as TC,musteriAd as Ad,musteriSoyad as Soyad", "musteriler", "0", "0");
        }

        private void users_Load(object sender, EventArgs e)
        {

        }

        private void btn_usersAdd_Click(object sender, EventArgs e)
        {
            userAdd uA = new userAdd();
            showControl(uA);
        }

        private void btn_usersUpdate_Click(object sender, EventArgs e)
        {
            userUpdate uU = new userUpdate();
            showControl(uU);
        }

        private void btn_usersDelete_Click(object sender, EventArgs e)
        {
            userDelete uD = new userDelete();
            showControl(uD);
        }

        private void tb_userSearch_TextChanged(object sender, EventArgs e)
        {
            data_users.DataSource = vt.verial("musteriTc as TC,musteriAd as Ad,musteriSoyad as Soyad", "musteriler", "0", "musteriTc LIKE '%"+tb_userSearch.Text+"%'");
        }
    }
}
