﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace arackiralama
{
    public partial class sigorta : UserControl
    {
        public sigorta()
        {
            InitializeComponent();
        }
        vtClass vt = new vtClass(false);
        public void rSigorta()
        {
            data_sigorta.DataSource = vt.verial("sigortaID as ID, sigortaAd as SigortaAdı, sigortaUcret as Ücret, sigortaBilgi as Açıklama", "sigortalar", "0", "0");
            cb_sigorta.DataSource = vt.verial("*", "sigortalar", "0", "0");
            cb_sigorta.ValueMember = "sigortaID";
            cb_sigorta.DisplayMember = "sigortaAd";
        }
        private void sigorta_Load(object sender, EventArgs e)
        {
            rSigorta();
        }

        private void btn_sigortaAdd_Click(object sender, EventArgs e)
        {
            vt.veriekle("sigortalar",tb_sigortaAd.Text,tb_sigortaUcret.Text,rtb_sigortaBilgi.Text);
            rSigorta();
        }

        private void btn_sigortaUpdate_Click(object sender, EventArgs e)
        {
            vt.kayitGuncelle("sigortalar","sigortaAd",tb_sigortaAd.Text, tb_sigortaAd.Text,tb_sigortaUcret.Text,rtb_sigortaBilgi.Text);
            rSigorta();
        }

        private void btn_sigortaDelete_Click(object sender, EventArgs e)
        {
            vt.verisil("sigortalar","sigortaID",cb_sigorta.SelectedValue);
            rSigorta();
        }

        private void data_sigorta_CellMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            tb_sigortaAd.Text = data_sigorta.CurrentRow.Cells[1].Value.ToString();
            tb_sigortaUcret.Text = data_sigorta.CurrentRow.Cells[2].Value.ToString();
            rtb_sigortaBilgi.Text = data_sigorta.CurrentRow.Cells[3].Value.ToString();
        }
    }
}
