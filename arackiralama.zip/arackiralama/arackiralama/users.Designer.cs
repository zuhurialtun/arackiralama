﻿namespace arackiralama
{
    partial class users
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.pnl_usersMenu = new System.Windows.Forms.Panel();
            this.btn_usersDelete = new System.Windows.Forms.Button();
            this.btn_usersUpdate = new System.Windows.Forms.Button();
            this.btn_usersAdd = new System.Windows.Forms.Button();
            this.btn_usersList = new System.Windows.Forms.Button();
            this.pnl_users = new System.Windows.Forms.Panel();
            this.users_Content = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.tb_userSearch = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.data_users = new System.Windows.Forms.DataGridView();
            this.pnl_usersMenu.SuspendLayout();
            this.pnl_users.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.data_users)).BeginInit();
            this.SuspendLayout();
            // 
            // pnl_usersMenu
            // 
            this.pnl_usersMenu.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(36)))), ((int)(((byte)(35)))));
            this.pnl_usersMenu.Controls.Add(this.btn_usersDelete);
            this.pnl_usersMenu.Controls.Add(this.btn_usersUpdate);
            this.pnl_usersMenu.Controls.Add(this.btn_usersAdd);
            this.pnl_usersMenu.Controls.Add(this.btn_usersList);
            this.pnl_usersMenu.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnl_usersMenu.Location = new System.Drawing.Point(0, 0);
            this.pnl_usersMenu.Name = "pnl_usersMenu";
            this.pnl_usersMenu.Size = new System.Drawing.Size(1064, 50);
            this.pnl_usersMenu.TabIndex = 0;
            // 
            // btn_usersDelete
            // 
            this.btn_usersDelete.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(36)))), ((int)(((byte)(35)))));
            this.btn_usersDelete.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btn_usersDelete.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_usersDelete.Dock = System.Windows.Forms.DockStyle.Left;
            this.btn_usersDelete.FlatAppearance.BorderSize = 0;
            this.btn_usersDelete.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.btn_usersDelete.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.btn_usersDelete.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_usersDelete.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btn_usersDelete.ForeColor = System.Drawing.Color.White;
            this.btn_usersDelete.Location = new System.Drawing.Point(600, 0);
            this.btn_usersDelete.Name = "btn_usersDelete";
            this.btn_usersDelete.Size = new System.Drawing.Size(200, 50);
            this.btn_usersDelete.TabIndex = 6;
            this.btn_usersDelete.Text = "Müşteri Sil";
            this.btn_usersDelete.UseVisualStyleBackColor = false;
            this.btn_usersDelete.Click += new System.EventHandler(this.btn_usersDelete_Click);
            // 
            // btn_usersUpdate
            // 
            this.btn_usersUpdate.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(36)))), ((int)(((byte)(35)))));
            this.btn_usersUpdate.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btn_usersUpdate.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_usersUpdate.Dock = System.Windows.Forms.DockStyle.Left;
            this.btn_usersUpdate.FlatAppearance.BorderSize = 0;
            this.btn_usersUpdate.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.btn_usersUpdate.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.btn_usersUpdate.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_usersUpdate.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btn_usersUpdate.ForeColor = System.Drawing.Color.White;
            this.btn_usersUpdate.Location = new System.Drawing.Point(400, 0);
            this.btn_usersUpdate.Name = "btn_usersUpdate";
            this.btn_usersUpdate.Size = new System.Drawing.Size(200, 50);
            this.btn_usersUpdate.TabIndex = 5;
            this.btn_usersUpdate.Text = "Müşteri Güncelle";
            this.btn_usersUpdate.UseVisualStyleBackColor = false;
            this.btn_usersUpdate.Click += new System.EventHandler(this.btn_usersUpdate_Click);
            // 
            // btn_usersAdd
            // 
            this.btn_usersAdd.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(36)))), ((int)(((byte)(35)))));
            this.btn_usersAdd.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btn_usersAdd.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_usersAdd.Dock = System.Windows.Forms.DockStyle.Left;
            this.btn_usersAdd.FlatAppearance.BorderSize = 0;
            this.btn_usersAdd.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.btn_usersAdd.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.btn_usersAdd.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_usersAdd.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btn_usersAdd.ForeColor = System.Drawing.Color.White;
            this.btn_usersAdd.Location = new System.Drawing.Point(200, 0);
            this.btn_usersAdd.Name = "btn_usersAdd";
            this.btn_usersAdd.Size = new System.Drawing.Size(200, 50);
            this.btn_usersAdd.TabIndex = 4;
            this.btn_usersAdd.Text = "Müşteri Kayıt";
            this.btn_usersAdd.UseVisualStyleBackColor = false;
            this.btn_usersAdd.Click += new System.EventHandler(this.btn_usersAdd_Click);
            // 
            // btn_usersList
            // 
            this.btn_usersList.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(36)))), ((int)(((byte)(35)))));
            this.btn_usersList.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btn_usersList.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_usersList.Dock = System.Windows.Forms.DockStyle.Left;
            this.btn_usersList.FlatAppearance.BorderSize = 0;
            this.btn_usersList.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.btn_usersList.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.btn_usersList.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_usersList.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btn_usersList.ForeColor = System.Drawing.Color.White;
            this.btn_usersList.Location = new System.Drawing.Point(0, 0);
            this.btn_usersList.Name = "btn_usersList";
            this.btn_usersList.Size = new System.Drawing.Size(200, 50);
            this.btn_usersList.TabIndex = 3;
            this.btn_usersList.Text = "Müşterileri Listele";
            this.btn_usersList.UseVisualStyleBackColor = false;
            this.btn_usersList.Click += new System.EventHandler(this.btn_usersList_Click);
            // 
            // pnl_users
            // 
            this.pnl_users.Controls.Add(this.users_Content);
            this.pnl_users.Controls.Add(this.panel3);
            this.pnl_users.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnl_users.Location = new System.Drawing.Point(0, 50);
            this.pnl_users.Name = "pnl_users";
            this.pnl_users.Size = new System.Drawing.Size(1064, 531);
            this.pnl_users.TabIndex = 1;
            // 
            // users_Content
            // 
            this.users_Content.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(237)))), ((int)(((byte)(223)))));
            this.users_Content.Dock = System.Windows.Forms.DockStyle.Fill;
            this.users_Content.Location = new System.Drawing.Point(400, 0);
            this.users_Content.Name = "users_Content";
            this.users_Content.Size = new System.Drawing.Size(664, 531);
            this.users_Content.TabIndex = 1;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(237)))), ((int)(((byte)(223)))));
            this.panel3.Controls.Add(this.panel1);
            this.panel3.Controls.Add(this.data_users);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel3.Location = new System.Drawing.Point(0, 0);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(400, 531);
            this.panel3.TabIndex = 0;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(237)))), ((int)(((byte)(223)))));
            this.panel1.Controls.Add(this.tb_userSearch);
            this.panel1.Controls.Add(this.label12);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(400, 55);
            this.panel1.TabIndex = 1;
            // 
            // tb_userSearch
            // 
            this.tb_userSearch.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(36)))), ((int)(((byte)(35)))));
            this.tb_userSearch.Location = new System.Drawing.Point(57, 17);
            this.tb_userSearch.Name = "tb_userSearch";
            this.tb_userSearch.Size = new System.Drawing.Size(333, 20);
            this.tb_userSearch.TabIndex = 4;
            this.tb_userSearch.TextChanged += new System.EventHandler(this.tb_userSearch_TextChanged);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label12.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(36)))), ((int)(((byte)(35)))));
            this.label12.Location = new System.Drawing.Point(10, 17);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(40, 16);
            this.label12.TabIndex = 3;
            this.label12.Text = "Ara :";
            // 
            // data_users
            // 
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.data_users.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.data_users.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.data_users.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(237)))), ((int)(((byte)(223)))));
            this.data_users.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.data_users.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(245)))), ((int)(((byte)(203)))), ((int)(((byte)(92)))));
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(36)))), ((int)(((byte)(35)))));
            dataGridViewCellStyle2.Padding = new System.Windows.Forms.Padding(1, 2, 0, 1);
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(237)))), ((int)(((byte)(223)))));
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(36)))), ((int)(((byte)(35)))));
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.data_users.DefaultCellStyle = dataGridViewCellStyle2;
            this.data_users.Location = new System.Drawing.Point(0, 53);
            this.data_users.Name = "data_users";
            this.data_users.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.data_users.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.data_users.Size = new System.Drawing.Size(400, 478);
            this.data_users.TabIndex = 0;
            // 
            // users
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.pnl_users);
            this.Controls.Add(this.pnl_usersMenu);
            this.Name = "users";
            this.Size = new System.Drawing.Size(1064, 581);
            this.Load += new System.EventHandler(this.users_Load);
            this.pnl_usersMenu.ResumeLayout(false);
            this.pnl_users.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.data_users)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnl_usersMenu;
        private System.Windows.Forms.Panel pnl_users;
        private System.Windows.Forms.Button btn_usersDelete;
        private System.Windows.Forms.Button btn_usersUpdate;
        private System.Windows.Forms.Button btn_usersAdd;
        private System.Windows.Forms.Button btn_usersList;
        private System.Windows.Forms.Panel users_Content;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.DataGridView data_users;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox tb_userSearch;
        private System.Windows.Forms.Label label12;
    }
}
