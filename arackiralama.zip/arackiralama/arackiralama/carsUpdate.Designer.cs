﻿namespace arackiralama
{
    partial class carsUpdate
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.btn_userUpdate = new System.Windows.Forms.Button();
            this.rtb_aracAdres = new System.Windows.Forms.RichTextBox();
            this.tb_aracKira = new System.Windows.Forms.TextBox();
            this.tb_aracKisi = new System.Windows.Forms.TextBox();
            this.tb_aracKm = new System.Windows.Forms.TextBox();
            this.cb_il = new System.Windows.Forms.ComboBox();
            this.cb_AracKlima = new System.Windows.Forms.ComboBox();
            this.cb_aracRenk = new System.Windows.Forms.ComboBox();
            this.cb_aracCekisTip = new System.Windows.Forms.ComboBox();
            this.cb_AracVitesTip = new System.Windows.Forms.ComboBox();
            this.cb_aracYakitTip = new System.Windows.Forms.ComboBox();
            this.tb_aracYil = new System.Windows.Forms.TextBox();
            this.tb_aracPlaka = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.cb_model = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.dataG_car = new System.Windows.Forms.DataGridView();
            this.label14 = new System.Windows.Forms.Label();
            this.cb_marka = new System.Windows.Forms.ComboBox();
            ((System.ComponentModel.ISupportInitialize)(this.dataG_car)).BeginInit();
            this.SuspendLayout();
            // 
            // btn_userUpdate
            // 
            this.btn_userUpdate.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(207)))), ((int)(((byte)(219)))), ((int)(((byte)(213)))));
            this.btn_userUpdate.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_userUpdate.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(36)))), ((int)(((byte)(35)))));
            this.btn_userUpdate.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_userUpdate.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btn_userUpdate.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(36)))), ((int)(((byte)(35)))));
            this.btn_userUpdate.Location = new System.Drawing.Point(355, 348);
            this.btn_userUpdate.Name = "btn_userUpdate";
            this.btn_userUpdate.Size = new System.Drawing.Size(268, 50);
            this.btn_userUpdate.TabIndex = 58;
            this.btn_userUpdate.Text = "Güncelle";
            this.btn_userUpdate.UseVisualStyleBackColor = false;
            this.btn_userUpdate.Click += new System.EventHandler(this.btn_userUpdate_Click);
            // 
            // rtb_aracAdres
            // 
            this.rtb_aracAdres.Location = new System.Drawing.Point(355, 200);
            this.rtb_aracAdres.Name = "rtb_aracAdres";
            this.rtb_aracAdres.Size = new System.Drawing.Size(268, 142);
            this.rtb_aracAdres.TabIndex = 56;
            this.rtb_aracAdres.Text = "";
            // 
            // tb_aracKira
            // 
            this.tb_aracKira.Location = new System.Drawing.Point(170, 473);
            this.tb_aracKira.Name = "tb_aracKira";
            this.tb_aracKira.Size = new System.Drawing.Size(145, 20);
            this.tb_aracKira.TabIndex = 55;
            // 
            // tb_aracKisi
            // 
            this.tb_aracKisi.Location = new System.Drawing.Point(171, 363);
            this.tb_aracKisi.Name = "tb_aracKisi";
            this.tb_aracKisi.Size = new System.Drawing.Size(145, 20);
            this.tb_aracKisi.TabIndex = 54;
            // 
            // tb_aracKm
            // 
            this.tb_aracKm.Location = new System.Drawing.Point(171, 310);
            this.tb_aracKm.Name = "tb_aracKm";
            this.tb_aracKm.Size = new System.Drawing.Size(145, 20);
            this.tb_aracKm.TabIndex = 53;
            // 
            // cb_il
            // 
            this.cb_il.FormattingEnabled = true;
            this.cb_il.Location = new System.Drawing.Point(170, 446);
            this.cb_il.Name = "cb_il";
            this.cb_il.Size = new System.Drawing.Size(145, 21);
            this.cb_il.TabIndex = 52;
            // 
            // cb_AracKlima
            // 
            this.cb_AracKlima.FormattingEnabled = true;
            this.cb_AracKlima.Location = new System.Drawing.Point(170, 419);
            this.cb_AracKlima.Name = "cb_AracKlima";
            this.cb_AracKlima.Size = new System.Drawing.Size(145, 21);
            this.cb_AracKlima.TabIndex = 51;
            // 
            // cb_aracRenk
            // 
            this.cb_aracRenk.FormattingEnabled = true;
            this.cb_aracRenk.Location = new System.Drawing.Point(171, 392);
            this.cb_aracRenk.Name = "cb_aracRenk";
            this.cb_aracRenk.Size = new System.Drawing.Size(145, 21);
            this.cb_aracRenk.TabIndex = 50;
            // 
            // cb_aracCekisTip
            // 
            this.cb_aracCekisTip.FormattingEnabled = true;
            this.cb_aracCekisTip.Location = new System.Drawing.Point(171, 336);
            this.cb_aracCekisTip.Name = "cb_aracCekisTip";
            this.cb_aracCekisTip.Size = new System.Drawing.Size(145, 21);
            this.cb_aracCekisTip.TabIndex = 49;
            // 
            // cb_AracVitesTip
            // 
            this.cb_AracVitesTip.FormattingEnabled = true;
            this.cb_AracVitesTip.Location = new System.Drawing.Point(171, 283);
            this.cb_AracVitesTip.Name = "cb_AracVitesTip";
            this.cb_AracVitesTip.Size = new System.Drawing.Size(145, 21);
            this.cb_AracVitesTip.TabIndex = 48;
            // 
            // cb_aracYakitTip
            // 
            this.cb_aracYakitTip.FormattingEnabled = true;
            this.cb_aracYakitTip.Location = new System.Drawing.Point(171, 255);
            this.cb_aracYakitTip.Name = "cb_aracYakitTip";
            this.cb_aracYakitTip.Size = new System.Drawing.Size(145, 21);
            this.cb_aracYakitTip.TabIndex = 47;
            // 
            // tb_aracYil
            // 
            this.tb_aracYil.Location = new System.Drawing.Point(171, 229);
            this.tb_aracYil.Name = "tb_aracYil";
            this.tb_aracYil.Size = new System.Drawing.Size(145, 20);
            this.tb_aracYil.TabIndex = 46;
            // 
            // tb_aracPlaka
            // 
            this.tb_aracPlaka.Location = new System.Drawing.Point(171, 24);
            this.tb_aracPlaka.MaxLength = 8;
            this.tb_aracPlaka.Name = "tb_aracPlaka";
            this.tb_aracPlaka.Size = new System.Drawing.Size(145, 20);
            this.tb_aracPlaka.TabIndex = 45;
            this.tb_aracPlaka.TextChanged += new System.EventHandler(this.tb_aracPlaka_TextChanged);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label13.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(36)))), ((int)(((byte)(35)))));
            this.label13.Location = new System.Drawing.Point(41, 477);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(124, 16);
            this.label13.TabIndex = 44;
            this.label13.Text = "Araç Kira Ücreti :";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label12.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(36)))), ((int)(((byte)(35)))));
            this.label12.Location = new System.Drawing.Point(352, 180);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(97, 16);
            this.label12.TabIndex = 43;
            this.label12.Text = "Araç Adresi :";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label11.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(36)))), ((int)(((byte)(35)))));
            this.label11.Location = new System.Drawing.Point(105, 451);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(60, 16);
            this.label11.TabIndex = 42;
            this.label11.Text = "Araç İl :";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label10.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(36)))), ((int)(((byte)(35)))));
            this.label10.Location = new System.Drawing.Point(75, 424);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(90, 16);
            this.label10.TabIndex = 41;
            this.label10.Text = "Araç Klima :";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label9.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(36)))), ((int)(((byte)(35)))));
            this.label9.Location = new System.Drawing.Point(72, 397);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(93, 16);
            this.label9.TabIndex = 40;
            this.label9.Text = "Araç Rengi :";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(36)))), ((int)(((byte)(35)))));
            this.label8.Location = new System.Drawing.Point(11, 367);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(154, 16);
            this.label8.TabIndex = 39;
            this.label8.Text = "Araç Kişi Kapasitesi :";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(36)))), ((int)(((byte)(35)))));
            this.label7.Location = new System.Drawing.Point(43, 341);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(122, 16);
            this.label7.TabIndex = 38;
            this.label7.Text = "Araç Çekiş Tipi :";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(36)))), ((int)(((byte)(35)))));
            this.label6.Location = new System.Drawing.Point(92, 314);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(73, 16);
            this.label6.TabIndex = 37;
            this.label6.Text = "Araç Km :";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(36)))), ((int)(((byte)(35)))));
            this.label5.Location = new System.Drawing.Point(47, 288);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(118, 16);
            this.label5.TabIndex = 36;
            this.label5.Text = "Araç Vites Tipi :";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(36)))), ((int)(((byte)(35)))));
            this.label4.Location = new System.Drawing.Point(47, 260);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(118, 16);
            this.label4.TabIndex = 35;
            this.label4.Text = "Araç Yakıt Tipi :";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(36)))), ((int)(((byte)(35)))));
            this.label3.Location = new System.Drawing.Point(91, 233);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(74, 16);
            this.label3.TabIndex = 34;
            this.label3.Text = "Araç Yılı :";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(36)))), ((int)(((byte)(35)))));
            this.label2.Location = new System.Drawing.Point(70, 202);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(95, 16);
            this.label2.TabIndex = 33;
            this.label2.Text = "Araç Model :";
            // 
            // cb_model
            // 
            this.cb_model.FormattingEnabled = true;
            this.cb_model.Location = new System.Drawing.Point(171, 202);
            this.cb_model.Name = "cb_model";
            this.cb_model.Size = new System.Drawing.Size(145, 21);
            this.cb_model.TabIndex = 32;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(36)))), ((int)(((byte)(35)))));
            this.label1.Location = new System.Drawing.Point(73, 24);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(92, 16);
            this.label1.TabIndex = 31;
            this.label1.Text = "Araç Plaka :";
            // 
            // dataG_car
            // 
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.dataG_car.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dataG_car.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataG_car.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(237)))), ((int)(((byte)(223)))));
            this.dataG_car.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dataG_car.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(245)))), ((int)(((byte)(203)))), ((int)(((byte)(92)))));
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(36)))), ((int)(((byte)(35)))));
            dataGridViewCellStyle2.Padding = new System.Windows.Forms.Padding(1, 2, 0, 1);
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(237)))), ((int)(((byte)(223)))));
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(36)))), ((int)(((byte)(35)))));
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataG_car.DefaultCellStyle = dataGridViewCellStyle2;
            this.dataG_car.Location = new System.Drawing.Point(14, 50);
            this.dataG_car.MaximumSize = new System.Drawing.Size(609, 108);
            this.dataG_car.Name = "dataG_car";
            this.dataG_car.ReadOnly = true;
            this.dataG_car.ScrollBars = System.Windows.Forms.ScrollBars.Horizontal;
            this.dataG_car.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataG_car.Size = new System.Drawing.Size(609, 80);
            this.dataG_car.TabIndex = 60;
            this.dataG_car.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataG_car_CellContentClick);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label14.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(36)))), ((int)(((byte)(35)))));
            this.label14.Location = new System.Drawing.Point(71, 175);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(95, 16);
            this.label14.TabIndex = 62;
            this.label14.Text = "Araç Marka :";
            // 
            // cb_marka
            // 
            this.cb_marka.FormattingEnabled = true;
            this.cb_marka.Location = new System.Drawing.Point(172, 175);
            this.cb_marka.Name = "cb_marka";
            this.cb_marka.Size = new System.Drawing.Size(145, 21);
            this.cb_marka.TabIndex = 61;
            this.cb_marka.SelectedIndexChanged += new System.EventHandler(this.cb_marka_SelectedIndexChanged);
            // 
            // carsUpdate
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(237)))), ((int)(((byte)(223)))));
            this.Controls.Add(this.label14);
            this.Controls.Add(this.cb_marka);
            this.Controls.Add(this.dataG_car);
            this.Controls.Add(this.btn_userUpdate);
            this.Controls.Add(this.rtb_aracAdres);
            this.Controls.Add(this.tb_aracKira);
            this.Controls.Add(this.tb_aracKisi);
            this.Controls.Add(this.tb_aracKm);
            this.Controls.Add(this.cb_il);
            this.Controls.Add(this.cb_AracKlima);
            this.Controls.Add(this.cb_aracRenk);
            this.Controls.Add(this.cb_aracCekisTip);
            this.Controls.Add(this.cb_AracVitesTip);
            this.Controls.Add(this.cb_aracYakitTip);
            this.Controls.Add(this.tb_aracYil);
            this.Controls.Add(this.tb_aracPlaka);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.cb_model);
            this.Controls.Add(this.label1);
            this.Name = "carsUpdate";
            this.Size = new System.Drawing.Size(664, 531);
            this.Load += new System.EventHandler(this.carsUpdate_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataG_car)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button btn_userUpdate;
        private System.Windows.Forms.RichTextBox rtb_aracAdres;
        private System.Windows.Forms.TextBox tb_aracKira;
        private System.Windows.Forms.TextBox tb_aracKisi;
        private System.Windows.Forms.TextBox tb_aracKm;
        private System.Windows.Forms.ComboBox cb_il;
        private System.Windows.Forms.ComboBox cb_AracKlima;
        private System.Windows.Forms.ComboBox cb_aracRenk;
        private System.Windows.Forms.ComboBox cb_aracCekisTip;
        private System.Windows.Forms.ComboBox cb_AracVitesTip;
        private System.Windows.Forms.ComboBox cb_aracYakitTip;
        private System.Windows.Forms.TextBox tb_aracYil;
        private System.Windows.Forms.TextBox tb_aracPlaka;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox cb_model;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView dataG_car;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.ComboBox cb_marka;
    }
}
