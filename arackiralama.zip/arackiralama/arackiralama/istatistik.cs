﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace arackiralama
{
    public partial class istatistik : UserControl
    {
        public istatistik()
        {
            InitializeComponent();
        }
        vtClass vt = new vtClass(false);
        public void showControl(Control control)
        {
            ist_Content.Controls.Clear();
            control.Dock = DockStyle.Fill;
            control.BringToFront();
            control.Focus();
            ist_Content.Controls.Add(control);
        }
        private void btn_carsInfo_Click(object sender, EventArgs e)
        {
            carsİ hp = new carsİ();
            showControl(hp);
        }

        private void btn_usersInfo_Click(object sender, EventArgs e)
        {
            usersİ hp = new usersİ();
            showControl(hp);
        }

        private void btn_kiraAll_Click(object sender, EventArgs e)
        {
            fullList fL = new fullList(vt.verial("(modeller.modelAd+' '+araclar.aracPlaka) as Araç, (musteriler.musteriAd + ' '+ musteriler.musteriSoyad) as Müşteri, (sigortalar.sigortaAd + ' '+ CONVERT(varchar(8),sigortalar.sigortaUcret) +' TL') as Sigorta, CONVERT(varchar(8),kiralama.kiraUcret)+' TL' as TOPLAMTUTAR,kiralama.kiraGirisTarih as BaşlangıçTarihi,kiralama.kiraBitisTarih as BitişTarihi, iller.ilAd as İl", "kiralama", "INNER JOIN musteriler ON musteriler.musteriID=kiralama.kiraMusteriID INNER JOIN sigortalar On sigortalar.sigortaID=kiralama.kiraSigorta INNER JOIN araclar ON araclar.aracID=kiralama.kiraAracID INNER JOIN modeller ON modeller.modelID=araclar.modelID INNER JOIN iller ON iller.ilID=kiralama.kiraIl", "0"));
            showControl(fL);
        }
    }
}
