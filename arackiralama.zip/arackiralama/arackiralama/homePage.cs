﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace arackiralama
{
    public partial class homePage : UserControl
    {
        public homePage()
        {
            InitializeComponent();
        }
        vtClass vt = new vtClass(false);
        private void timer1_Tick(object sender, EventArgs e)
        {
            lbl_time.Text = "Sistem Zamanı : " + DateTime.Now;
            try
            {
                lbl_carsCount.Text = vt.verial("Count(aracID)", "araclar", "0", "0").Rows[0][0].ToString() + " araç";

                lbl_usersCount.Text = vt.verial("Count(musteriID)", "musteriler", "0", "0").Rows[0][0].ToString() + " müşteri";
                
                lbl_moneyCount.Text = vt.verial("SUM(kiraUcret)", "kiralama", "0", "kiraGirisTarih >= '" + (DateTime.Now.Year.ToString() + "-" + DateTime.Now.Month.ToString() + "-1") + "'").Rows[0][0].ToString() + " TL";
            }
            catch (Exception h)
            {
                if (vt.HataYakala == true)
                {
                    MessageBox.Show(h.Message);
                }
            }
        }

        private void homePage_Load(object sender, EventArgs e)
        {
            
        }
    }
}
