﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace arackiralama
{
    public partial class aracKirala : UserControl
    {
        public aracKirala()
        {
            InitializeComponent();
    }
        vtClass vt = new vtClass(false);
        public double total=0;
        public void aracYenile()
        {
            cb_cars.DataSource = vt.verial("araclar.aracID,(modeller.modelAd +' '+ araclar.aracPlaka) as arac", "araclar", "INNER JOIN modeller ON modeller.modelID = araclar.modelID", "aracKiraDurum='0'");
            cb_cars.ValueMember = "aracID";
            cb_cars.DisplayMember = "arac";

            cb_carsKirada.DataSource = vt.verial("araclar.aracID,(modeller.modelAd +' '+ araclar.aracPlaka) as arac", "araclar", "INNER JOIN modeller ON modeller.modelID = araclar.modelID", "aracKiraDurum='1'");
            cb_carsKirada.ValueMember = "aracID";
            cb_carsKirada.DisplayMember = "arac";
        }
        private void aracKirala_Load(object sender, EventArgs e)
        {
            cb_musteri.DataSource = vt.verial("*", "musteriler", "0", "0");
            cb_musteri.ValueMember = "musteriID";
            cb_musteri.DisplayMember = "musteriTc";

            aracYenile();

            cb_sigorta.DataSource = vt.verial("*", "sigortalar", "0", "0");
            cb_sigorta.ValueMember = "sigortaID";
            cb_sigorta.DisplayMember = "sigortaAd";

            cb_iller.DataSource = vt.verial("*", "iller", "0", "0");
            cb_iller.ValueMember = "ilID";
            cb_iller.DisplayMember = "ilAd";
        }

        private void btn_kiraAdd_Click(object sender, EventArgs e)
        {
            TimeSpan Sonuc = Convert.ToDateTime(dt_end.Text) - Convert.ToDateTime(dt_start.Text);
            double kiragun = Sonuc.TotalDays;
            if (kiragun<=30 && kiragun>0)
            {
                if (vt.veriekle("kiralama", cb_musteri.SelectedValue, cb_cars.SelectedValue, cb_sigorta.SelectedValue, int.Parse(total.ToString()), dt_start.Value.Date.ToString("yyyy-MM-dd"), dt_end.Value.Date.ToString("yyyy-MM-dd"), cb_iller.SelectedValue, rtb_aracAdres.Text))
                {
                    vt.sorguGonder("UPDATE araclar SET aracKiraDurum = '1' Where aracID = '"+cb_cars.SelectedValue+"'");
                    aracYenile();
                    MessageBox.Show("Kiralama Kaydı Başarılı.");
                }
                else
                {
                    MessageBox.Show("Kiralama Kaydı Başarısız!");
                }
            }
            else
            {
                MessageBox.Show("30 günden fazla veya 0 günden az sürede kiralama yapılamaz!");
            }
        }

        private void toplamTutar(object sender, EventArgs e)
        {
            try
            {
                if (cb_cars.Items.Count > 0)
                {
                    double aracUcret = Convert.ToDouble((vt.verial("aracKiraUcret", "araclar", "0", ("aracID LIKE " + cb_cars.SelectedValue)).Rows[0][0]).ToString());
                    double sigortaUcret = Convert.ToDouble((vt.verial("sigortaUcret", "sigortalar", "0", ("sigortaID LIKE " + cb_sigorta.SelectedValue)).Rows[0][0]).ToString());
                    lbl_aracUcret.Text= aracUcret + " TL";
                    lbl_sigortaUcret.Text = sigortaUcret + " TL";
                    TimeSpan Sonuc = Convert.ToDateTime(dt_end.Text) - Convert.ToDateTime(dt_start.Text);
                    double kiragun = Sonuc.TotalDays;
                    lbl_kiraGun.Text = kiragun + " Gün";
                    total = ((kiragun * aracUcret) + sigortaUcret);
                }
                lbl_toplamTutar.Text = "Toplam Tutar: " + total + " TL";
            }
            catch (Exception h)
            {
                if (vt.HataYakala == true)
                {
                    MessageBox.Show(h.Message);
                }
            }
        }

        private void btn_kiraOut_Click(object sender, EventArgs e)
        {
            vt.sorguGonder("UPDATE araclar SET aracKiraDurum = '0' Where aracID = '" + cb_carsKirada.SelectedValue + "'");
            aracYenile();
        }
    }
}
