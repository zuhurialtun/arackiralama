﻿namespace arackiralama
{
    partial class cars
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.pnl_carsMenu = new System.Windows.Forms.Panel();
            this.btn_carsExtra = new System.Windows.Forms.Button();
            this.btn_carsDelete = new System.Windows.Forms.Button();
            this.btn_carsUpdate = new System.Windows.Forms.Button();
            this.btn_carsAdd = new System.Windows.Forms.Button();
            this.btn_carsList = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.cars_Content = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.data_cars = new System.Windows.Forms.DataGridView();
            this.panel1 = new System.Windows.Forms.Panel();
            this.tb_carSearch = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.pnl_carsMenu.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.data_cars)).BeginInit();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnl_carsMenu
            // 
            this.pnl_carsMenu.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(36)))), ((int)(((byte)(35)))));
            this.pnl_carsMenu.Controls.Add(this.btn_carsExtra);
            this.pnl_carsMenu.Controls.Add(this.btn_carsDelete);
            this.pnl_carsMenu.Controls.Add(this.btn_carsUpdate);
            this.pnl_carsMenu.Controls.Add(this.btn_carsAdd);
            this.pnl_carsMenu.Controls.Add(this.btn_carsList);
            this.pnl_carsMenu.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnl_carsMenu.Location = new System.Drawing.Point(0, 0);
            this.pnl_carsMenu.Name = "pnl_carsMenu";
            this.pnl_carsMenu.Size = new System.Drawing.Size(1064, 50);
            this.pnl_carsMenu.TabIndex = 0;
            // 
            // btn_carsExtra
            // 
            this.btn_carsExtra.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(36)))), ((int)(((byte)(35)))));
            this.btn_carsExtra.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btn_carsExtra.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_carsExtra.Dock = System.Windows.Forms.DockStyle.Left;
            this.btn_carsExtra.FlatAppearance.BorderSize = 0;
            this.btn_carsExtra.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.btn_carsExtra.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.btn_carsExtra.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_carsExtra.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btn_carsExtra.ForeColor = System.Drawing.Color.White;
            this.btn_carsExtra.Location = new System.Drawing.Point(800, 0);
            this.btn_carsExtra.Name = "btn_carsExtra";
            this.btn_carsExtra.Size = new System.Drawing.Size(200, 50);
            this.btn_carsExtra.TabIndex = 7;
            this.btn_carsExtra.Text = "Marka-Model Ekle";
            this.btn_carsExtra.UseVisualStyleBackColor = false;
            this.btn_carsExtra.Click += new System.EventHandler(this.btn_carsExtra_Click);
            // 
            // btn_carsDelete
            // 
            this.btn_carsDelete.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(36)))), ((int)(((byte)(35)))));
            this.btn_carsDelete.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btn_carsDelete.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_carsDelete.Dock = System.Windows.Forms.DockStyle.Left;
            this.btn_carsDelete.FlatAppearance.BorderSize = 0;
            this.btn_carsDelete.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.btn_carsDelete.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.btn_carsDelete.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_carsDelete.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btn_carsDelete.ForeColor = System.Drawing.Color.White;
            this.btn_carsDelete.Location = new System.Drawing.Point(600, 0);
            this.btn_carsDelete.Name = "btn_carsDelete";
            this.btn_carsDelete.Size = new System.Drawing.Size(200, 50);
            this.btn_carsDelete.TabIndex = 6;
            this.btn_carsDelete.Text = "Araç Silme";
            this.btn_carsDelete.UseVisualStyleBackColor = false;
            this.btn_carsDelete.Click += new System.EventHandler(this.btn_carsDelete_Click);
            // 
            // btn_carsUpdate
            // 
            this.btn_carsUpdate.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(36)))), ((int)(((byte)(35)))));
            this.btn_carsUpdate.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btn_carsUpdate.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_carsUpdate.Dock = System.Windows.Forms.DockStyle.Left;
            this.btn_carsUpdate.FlatAppearance.BorderSize = 0;
            this.btn_carsUpdate.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.btn_carsUpdate.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.btn_carsUpdate.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_carsUpdate.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btn_carsUpdate.ForeColor = System.Drawing.Color.White;
            this.btn_carsUpdate.Location = new System.Drawing.Point(400, 0);
            this.btn_carsUpdate.Name = "btn_carsUpdate";
            this.btn_carsUpdate.Size = new System.Drawing.Size(200, 50);
            this.btn_carsUpdate.TabIndex = 5;
            this.btn_carsUpdate.Text = "Araç Bilgisi Güncelle";
            this.btn_carsUpdate.UseVisualStyleBackColor = false;
            this.btn_carsUpdate.Click += new System.EventHandler(this.btn_carsUpdate_Click);
            // 
            // btn_carsAdd
            // 
            this.btn_carsAdd.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(36)))), ((int)(((byte)(35)))));
            this.btn_carsAdd.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btn_carsAdd.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_carsAdd.Dock = System.Windows.Forms.DockStyle.Left;
            this.btn_carsAdd.FlatAppearance.BorderSize = 0;
            this.btn_carsAdd.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.btn_carsAdd.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.btn_carsAdd.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_carsAdd.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btn_carsAdd.ForeColor = System.Drawing.Color.White;
            this.btn_carsAdd.Location = new System.Drawing.Point(200, 0);
            this.btn_carsAdd.Name = "btn_carsAdd";
            this.btn_carsAdd.Size = new System.Drawing.Size(200, 50);
            this.btn_carsAdd.TabIndex = 4;
            this.btn_carsAdd.Text = "Yeni Araç Ekle";
            this.btn_carsAdd.UseVisualStyleBackColor = false;
            this.btn_carsAdd.Click += new System.EventHandler(this.btn_carsAdd_Click);
            // 
            // btn_carsList
            // 
            this.btn_carsList.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(36)))), ((int)(((byte)(35)))));
            this.btn_carsList.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btn_carsList.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_carsList.Dock = System.Windows.Forms.DockStyle.Left;
            this.btn_carsList.FlatAppearance.BorderSize = 0;
            this.btn_carsList.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.btn_carsList.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.btn_carsList.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_carsList.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btn_carsList.ForeColor = System.Drawing.Color.White;
            this.btn_carsList.Location = new System.Drawing.Point(0, 0);
            this.btn_carsList.Name = "btn_carsList";
            this.btn_carsList.Size = new System.Drawing.Size(200, 50);
            this.btn_carsList.TabIndex = 3;
            this.btn_carsList.Text = "Araçları Listele";
            this.btn_carsList.UseVisualStyleBackColor = false;
            this.btn_carsList.Click += new System.EventHandler(this.btn_carsList_Click);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.cars_Content);
            this.panel2.Controls.Add(this.panel3);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(0, 50);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1064, 531);
            this.panel2.TabIndex = 1;
            // 
            // cars_Content
            // 
            this.cars_Content.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(237)))), ((int)(((byte)(223)))));
            this.cars_Content.Dock = System.Windows.Forms.DockStyle.Fill;
            this.cars_Content.Location = new System.Drawing.Point(400, 0);
            this.cars_Content.Name = "cars_Content";
            this.cars_Content.Size = new System.Drawing.Size(664, 531);
            this.cars_Content.TabIndex = 1;
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.data_cars);
            this.panel3.Controls.Add(this.panel1);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel3.Location = new System.Drawing.Point(0, 0);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(400, 531);
            this.panel3.TabIndex = 0;
            // 
            // data_cars
            // 
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.data_cars.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.data_cars.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.data_cars.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(237)))), ((int)(((byte)(223)))));
            this.data_cars.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.data_cars.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(245)))), ((int)(((byte)(203)))), ((int)(((byte)(92)))));
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(36)))), ((int)(((byte)(35)))));
            dataGridViewCellStyle2.Padding = new System.Windows.Forms.Padding(1, 2, 0, 1);
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(237)))), ((int)(((byte)(223)))));
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(36)))), ((int)(((byte)(35)))));
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.data_cars.DefaultCellStyle = dataGridViewCellStyle2;
            this.data_cars.Location = new System.Drawing.Point(0, 53);
            this.data_cars.Name = "data_cars";
            this.data_cars.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.data_cars.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect;
            this.data_cars.Size = new System.Drawing.Size(400, 478);
            this.data_cars.TabIndex = 5;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(237)))), ((int)(((byte)(223)))));
            this.panel1.Controls.Add(this.tb_carSearch);
            this.panel1.Controls.Add(this.label12);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(400, 55);
            this.panel1.TabIndex = 3;
            // 
            // tb_carSearch
            // 
            this.tb_carSearch.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(36)))), ((int)(((byte)(35)))));
            this.tb_carSearch.Location = new System.Drawing.Point(57, 17);
            this.tb_carSearch.Name = "tb_carSearch";
            this.tb_carSearch.Size = new System.Drawing.Size(333, 20);
            this.tb_carSearch.TabIndex = 4;
            this.tb_carSearch.TextChanged += new System.EventHandler(this.tb_carSearch_TextChanged);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label12.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(36)))), ((int)(((byte)(35)))));
            this.label12.Location = new System.Drawing.Point(10, 17);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(40, 16);
            this.label12.TabIndex = 3;
            this.label12.Text = "Ara :";
            // 
            // cars
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.pnl_carsMenu);
            this.Name = "cars";
            this.Size = new System.Drawing.Size(1064, 581);
            this.pnl_carsMenu.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.data_cars)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnl_carsMenu;
        private System.Windows.Forms.Button btn_carsDelete;
        private System.Windows.Forms.Button btn_carsUpdate;
        private System.Windows.Forms.Button btn_carsAdd;
        private System.Windows.Forms.Button btn_carsList;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel cars_Content;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button btn_carsExtra;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox tb_carSearch;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.DataGridView data_cars;
    }
}
