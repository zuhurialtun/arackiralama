﻿namespace arackiralama
{
    partial class aracKirala
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label14 = new System.Windows.Forms.Label();
            this.cb_musteri = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.cb_cars = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.cb_sigorta = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.cb_iller = new System.Windows.Forms.ComboBox();
            this.dt_start = new System.Windows.Forms.DateTimePicker();
            this.dt_end = new System.Windows.Forms.DateTimePicker();
            this.lbl_toplamTutar = new System.Windows.Forms.Label();
            this.rtb_aracAdres = new System.Windows.Forms.RichTextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.btn_kiraAdd = new System.Windows.Forms.Button();
            this.lbl_aracUcret = new System.Windows.Forms.Label();
            this.lbl_sigortaUcret = new System.Windows.Forms.Label();
            this.lbl_kiraGun = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.cb_carsKirada = new System.Windows.Forms.ComboBox();
            this.btn_kiraOut = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label14.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(36)))), ((int)(((byte)(35)))));
            this.label14.Location = new System.Drawing.Point(66, 32);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(135, 16);
            this.label14.TabIndex = 36;
            this.label14.Text = "Kiralayan Müşteri :";
            // 
            // cb_musteri
            // 
            this.cb_musteri.FormattingEnabled = true;
            this.cb_musteri.Location = new System.Drawing.Point(207, 32);
            this.cb_musteri.Name = "cb_musteri";
            this.cb_musteri.Size = new System.Drawing.Size(269, 26);
            this.cb_musteri.TabIndex = 35;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(36)))), ((int)(((byte)(35)))));
            this.label2.Location = new System.Drawing.Point(67, 59);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(134, 16);
            this.label2.TabIndex = 34;
            this.label2.Text = "Kiralanacak Araç :";
            // 
            // cb_cars
            // 
            this.cb_cars.FormattingEnabled = true;
            this.cb_cars.Location = new System.Drawing.Point(207, 59);
            this.cb_cars.Name = "cb_cars";
            this.cb_cars.Size = new System.Drawing.Size(269, 26);
            this.cb_cars.TabIndex = 33;
            this.cb_cars.SelectedIndexChanged += new System.EventHandler(this.toplamTutar);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(36)))), ((int)(((byte)(35)))));
            this.label1.Location = new System.Drawing.Point(87, 86);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(114, 16);
            this.label1.TabIndex = 38;
            this.label1.Text = "Araç Sigortası :";
            // 
            // cb_sigorta
            // 
            this.cb_sigorta.FormattingEnabled = true;
            this.cb_sigorta.Location = new System.Drawing.Point(207, 86);
            this.cb_sigorta.Name = "cb_sigorta";
            this.cb_sigorta.Size = new System.Drawing.Size(269, 26);
            this.cb_sigorta.TabIndex = 37;
            this.cb_sigorta.SelectedIndexChanged += new System.EventHandler(this.toplamTutar);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(36)))), ((int)(((byte)(35)))));
            this.label3.Location = new System.Drawing.Point(7, 140);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(194, 16);
            this.label3.TabIndex = 39;
            this.label3.Text = "Kiralama Başlangıç Tarihi :";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(36)))), ((int)(((byte)(35)))));
            this.label4.Location = new System.Drawing.Point(46, 166);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(155, 16);
            this.label4.TabIndex = 40;
            this.label4.Text = "Kiralama Bitiş Tarihi :";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(36)))), ((int)(((byte)(35)))));
            this.label5.Location = new System.Drawing.Point(91, 113);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(110, 16);
            this.label5.TabIndex = 42;
            this.label5.Text = "Kiralanacak İl :";
            // 
            // cb_iller
            // 
            this.cb_iller.FormattingEnabled = true;
            this.cb_iller.Location = new System.Drawing.Point(207, 113);
            this.cb_iller.Name = "cb_iller";
            this.cb_iller.Size = new System.Drawing.Size(269, 26);
            this.cb_iller.TabIndex = 41;
            // 
            // dt_start
            // 
            this.dt_start.Location = new System.Drawing.Point(207, 140);
            this.dt_start.Name = "dt_start";
            this.dt_start.Size = new System.Drawing.Size(269, 24);
            this.dt_start.TabIndex = 43;
            this.dt_start.ValueChanged += new System.EventHandler(this.toplamTutar);
            // 
            // dt_end
            // 
            this.dt_end.Location = new System.Drawing.Point(207, 166);
            this.dt_end.Name = "dt_end";
            this.dt_end.Size = new System.Drawing.Size(269, 24);
            this.dt_end.TabIndex = 44;
            this.dt_end.ValueChanged += new System.EventHandler(this.toplamTutar);
            // 
            // lbl_toplamTutar
            // 
            this.lbl_toplamTutar.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lbl_toplamTutar.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(36)))), ((int)(((byte)(35)))));
            this.lbl_toplamTutar.Location = new System.Drawing.Point(210, 202);
            this.lbl_toplamTutar.Name = "lbl_toplamTutar";
            this.lbl_toplamTutar.Size = new System.Drawing.Size(266, 21);
            this.lbl_toplamTutar.TabIndex = 45;
            this.lbl_toplamTutar.Text = "Toplam Kira Tutarı : 0 TL";
            // 
            // rtb_aracAdres
            // 
            this.rtb_aracAdres.Location = new System.Drawing.Point(548, 48);
            this.rtb_aracAdres.Name = "rtb_aracAdres";
            this.rtb_aracAdres.Size = new System.Drawing.Size(504, 142);
            this.rtb_aracAdres.TabIndex = 47;
            this.rtb_aracAdres.Text = "";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label12.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(36)))), ((int)(((byte)(35)))));
            this.label12.Location = new System.Drawing.Point(545, 29);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(97, 16);
            this.label12.TabIndex = 46;
            this.label12.Text = "Araç Adresi :";
            // 
            // btn_kiraAdd
            // 
            this.btn_kiraAdd.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(207)))), ((int)(((byte)(219)))), ((int)(((byte)(213)))));
            this.btn_kiraAdd.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_kiraAdd.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(36)))), ((int)(((byte)(35)))));
            this.btn_kiraAdd.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_kiraAdd.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btn_kiraAdd.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(36)))), ((int)(((byte)(35)))));
            this.btn_kiraAdd.Location = new System.Drawing.Point(210, 226);
            this.btn_kiraAdd.Name = "btn_kiraAdd";
            this.btn_kiraAdd.Size = new System.Drawing.Size(266, 50);
            this.btn_kiraAdd.TabIndex = 48;
            this.btn_kiraAdd.Text = "Aracı Kiraya Ver";
            this.btn_kiraAdd.UseVisualStyleBackColor = false;
            this.btn_kiraAdd.Click += new System.EventHandler(this.btn_kiraAdd_Click);
            // 
            // lbl_aracUcret
            // 
            this.lbl_aracUcret.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lbl_aracUcret.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(36)))), ((int)(((byte)(35)))));
            this.lbl_aracUcret.Location = new System.Drawing.Point(482, 59);
            this.lbl_aracUcret.Name = "lbl_aracUcret";
            this.lbl_aracUcret.Size = new System.Drawing.Size(60, 21);
            this.lbl_aracUcret.TabIndex = 49;
            this.lbl_aracUcret.Text = ": 0 TL";
            // 
            // lbl_sigortaUcret
            // 
            this.lbl_sigortaUcret.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lbl_sigortaUcret.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(36)))), ((int)(((byte)(35)))));
            this.lbl_sigortaUcret.Location = new System.Drawing.Point(482, 87);
            this.lbl_sigortaUcret.Name = "lbl_sigortaUcret";
            this.lbl_sigortaUcret.Size = new System.Drawing.Size(60, 21);
            this.lbl_sigortaUcret.TabIndex = 50;
            this.lbl_sigortaUcret.Text = ": 0 TL";
            // 
            // lbl_kiraGun
            // 
            this.lbl_kiraGun.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lbl_kiraGun.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(36)))), ((int)(((byte)(35)))));
            this.lbl_kiraGun.Location = new System.Drawing.Point(482, 166);
            this.lbl_kiraGun.Name = "lbl_kiraGun";
            this.lbl_kiraGun.Size = new System.Drawing.Size(60, 21);
            this.lbl_kiraGun.TabIndex = 51;
            this.lbl_kiraGun.Text = ": 0 Gün";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(36)))), ((int)(((byte)(35)))));
            this.label6.Location = new System.Drawing.Point(6, 34);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(191, 16);
            this.label6.TabIndex = 53;
            this.label6.Text = "Kiradan Çıkartılacak Araç :";
            // 
            // cb_carsKirada
            // 
            this.cb_carsKirada.FormattingEnabled = true;
            this.cb_carsKirada.Location = new System.Drawing.Point(203, 32);
            this.cb_carsKirada.Name = "cb_carsKirada";
            this.cb_carsKirada.Size = new System.Drawing.Size(273, 26);
            this.cb_carsKirada.TabIndex = 52;
            // 
            // btn_kiraOut
            // 
            this.btn_kiraOut.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(207)))), ((int)(((byte)(219)))), ((int)(((byte)(213)))));
            this.btn_kiraOut.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_kiraOut.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(36)))), ((int)(((byte)(35)))));
            this.btn_kiraOut.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_kiraOut.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btn_kiraOut.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(36)))), ((int)(((byte)(35)))));
            this.btn_kiraOut.Location = new System.Drawing.Point(203, 68);
            this.btn_kiraOut.Name = "btn_kiraOut";
            this.btn_kiraOut.Size = new System.Drawing.Size(273, 50);
            this.btn_kiraOut.TabIndex = 54;
            this.btn_kiraOut.Text = "Aracı Kiradan Çıkar";
            this.btn_kiraOut.UseVisualStyleBackColor = false;
            this.btn_kiraOut.Click += new System.EventHandler(this.btn_kiraOut_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(245)))), ((int)(((byte)(203)))), ((int)(((byte)(92)))));
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.cb_cars);
            this.groupBox2.Controls.Add(this.cb_musteri);
            this.groupBox2.Controls.Add(this.label14);
            this.groupBox2.Controls.Add(this.rtb_aracAdres);
            this.groupBox2.Controls.Add(this.label12);
            this.groupBox2.Controls.Add(this.lbl_kiraGun);
            this.groupBox2.Controls.Add(this.cb_sigorta);
            this.groupBox2.Controls.Add(this.lbl_sigortaUcret);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Controls.Add(this.lbl_aracUcret);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.btn_kiraAdd);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.cb_iller);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.lbl_toplamTutar);
            this.groupBox2.Controls.Add(this.dt_start);
            this.groupBox2.Controls.Add(this.dt_end);
            this.groupBox2.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.groupBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.groupBox2.Location = new System.Drawing.Point(3, 3);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(1061, 305);
            this.groupBox2.TabIndex = 55;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Araç Kiralama";
            // 
            // groupBox1
            // 
            this.groupBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(245)))), ((int)(((byte)(203)))), ((int)(((byte)(92)))));
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.cb_carsKirada);
            this.groupBox1.Controls.Add(this.btn_kiraOut);
            this.groupBox1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.groupBox1.Location = new System.Drawing.Point(3, 314);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(1058, 214);
            this.groupBox1.TabIndex = 56;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Kira İade";
            // 
            // aracKirala
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(237)))), ((int)(((byte)(223)))));
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.groupBox2);
            this.Name = "aracKirala";
            this.Size = new System.Drawing.Size(1064, 531);
            this.Load += new System.EventHandler(this.aracKirala_Load);
            this.Click += new System.EventHandler(this.btn_kiraOut_Click);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.ComboBox cb_musteri;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox cb_cars;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cb_sigorta;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox cb_iller;
        private System.Windows.Forms.DateTimePicker dt_start;
        private System.Windows.Forms.DateTimePicker dt_end;
        private System.Windows.Forms.Label lbl_toplamTutar;
        private System.Windows.Forms.RichTextBox rtb_aracAdres;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Button btn_kiraAdd;
        private System.Windows.Forms.Label lbl_aracUcret;
        private System.Windows.Forms.Label lbl_sigortaUcret;
        private System.Windows.Forms.Label lbl_kiraGun;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox cb_carsKirada;
        private System.Windows.Forms.Button btn_kiraOut;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox1;
    }
}
