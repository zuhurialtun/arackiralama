﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Windows.Forms;
using System.Collections;

namespace arackiralama
{
    class vtClass
    {
        public bool HataYakala = false;

        public vtClass(bool hata)
        {
            HataYakala = hata;
        }

        SqlConnection bag = new SqlConnection("server=PC\\SQLEXPRESS;initial catalog=arackiralama;integrated security = true");
        public DataTable verial(string alan, string tablo,string join, string sorgu)//kayıt çekme metodu
        {
            DataTable dt = new DataTable();
            try
            {
                bag.Open();
                string veriAlSorgu = "";
                //SqlDataAdapter da = new SqlDataAdapter("Select " + alan + " From " + tablo, bag);
                if (join=="0" && sorgu=="0")
                {
                    veriAlSorgu = ("Select " + alan + " From " + tablo);
                }
                else if (join != "0" && sorgu == "0")
                {
                    veriAlSorgu = ("Select " + alan + " From " + tablo + " " + join);
                    //da = new SqlDataAdapter("Select " + alan + " From " + tablo + " " + join, bag);
                }
                else if (sorgu != "0" && join == "0")
                {
                    veriAlSorgu = ("Select " + alan + " From " + tablo + " Where " + sorgu);
                    //da = new SqlDataAdapter("Select " + alan + " From " + tablo + " Where " + sorgu, bag);
                }
                else if (join != "0" && sorgu != "0")
                {
                    veriAlSorgu = ("Select " + alan + " From " + tablo + " " + join + " Where " + sorgu);
                    //da = new SqlDataAdapter("Select " + alan + " From " + tablo + " " + join + " Where " + sorgu, bag);
                }
                if (HataYakala==true)
                {
                    MessageBox.Show("Sql Sorgu = "+veriAlSorgu);
                }
                SqlCommand komut = new SqlCommand(veriAlSorgu,bag);
                SqlDataAdapter da = new SqlDataAdapter(komut);
                da.Fill(dt);
                bag.Close();
                veriAlSorgu = "";
            }
            catch (Exception e)
            {
                if (HataYakala == true)
                {
                    MessageBox.Show(e.Message);
                }
            }
            bag.Close();
            return dt;
        }
        public bool veriekle(string tablo, params object[] liste)//kayıt ekleme metodu
        {
            SqlCommand kmt = new SqlCommand();
            string ekleSorgu = "INSERT INTO " + tablo + " (";
            ArrayList KolonAdlariList;
            SqlDataAdapter da = new SqlDataAdapter("SELECT * FROM " + tablo, bag);
            DataTable dt2 = new DataTable();
            da.Fill(dt2);
            KolonAdlariList = new ArrayList();
            for (int i = 1; i < dt2.Columns.Count; i++)
            {
                DataColumn dr = dt2.Columns[i];
                KolonAdlariList.Add(dr.ToString());
            }
            for (int k = 0; k < KolonAdlariList.Count; k++)
            {
                if (k != KolonAdlariList.Count - 1)
                {
                    ekleSorgu = ekleSorgu + " " + KolonAdlariList[k] + ",";
                }
                else
                {
                    ekleSorgu = ekleSorgu + " " + KolonAdlariList[k];
                }
            }
            ekleSorgu = ekleSorgu + ") VALUES (";
            for (int i = 0; i < KolonAdlariList.Count; i++)
            {

                if (i != KolonAdlariList.Count - 1)
                {
                    if (liste[i] is string)
                    {
                        kmt.Parameters.AddWithValue("@" + KolonAdlariList[i].ToString() + "", liste[i].ToString());
                        ekleSorgu = ekleSorgu + "@" + KolonAdlariList[i] + ",";
                    }
                    else if (liste[i] is int)
                    {
                        kmt.Parameters.AddWithValue("@" + KolonAdlariList[i].ToString() + "", liste[i].ToString());
                        ekleSorgu = ekleSorgu + "@" + KolonAdlariList[i] + ",";
                    }
                    else
                    {
                        kmt.Parameters.AddWithValue("@" + KolonAdlariList[i].ToString() + "", null);
                        ekleSorgu = ekleSorgu + "@" + KolonAdlariList[i] + ",";
                    }
                }
                else
                {
                    if (liste[i] is string)
                    {
                        kmt.Parameters.AddWithValue("@" + KolonAdlariList[i].ToString() + "", liste[i]);
                        ekleSorgu = ekleSorgu + "@" + KolonAdlariList[i];
                    }
                    else if (liste[i] is int)
                    {
                        kmt.Parameters.AddWithValue("@" + KolonAdlariList[i].ToString() + "", liste[i]);
                        ekleSorgu = ekleSorgu + "@" + KolonAdlariList[i];
                    }
                    else
                    {
                        kmt.Parameters.AddWithValue("@" + KolonAdlariList[i].ToString() + "", null);
                        ekleSorgu = ekleSorgu + "@" + KolonAdlariList[i] + ",";
                    }
                }

            }
            ekleSorgu = ekleSorgu + ")";
            /////////////////////////////Sorgu Oluşturuldu
            if (HataYakala==true)
            {
                MessageBox.Show("Sql Sorgusu = "+ekleSorgu);
            }
            kmt.Connection = bag;
            kmt.CommandText = ekleSorgu;
            bag.Open();
            if (kmt.ExecuteNonQuery() ==1)
            {
                MessageBox.Show("Veri Kaydı Başarılı");
            }
            else
            {
                MessageBox.Show("Veri Kaydı Başarısız");
            }
            kmt.Dispose();
            bag.Close();
            return true;
        }
        public void verisil(string tablo, string alan, object deger)//kayıt silme metodu
        {
            SqlCommand kmt = new SqlCommand();
            bag.Open();
            kmt.Connection = bag;
            kmt.CommandText = "";
            if (deger is int)
            {
                kmt.CommandText = "DELETE FROM " + tablo + " WHERE " + alan + " = '" + (int)deger + "'";
            }
            else
            {
                kmt.CommandText = "DELETE FROM " + tablo + " WHERE " + alan + " = '" + (string)deger + "'";
            }
            if (kmt.ExecuteNonQuery() == 1)
            {
                bag.Close();
                MessageBox.Show("Veri Silindi");
            }
            else
            {
                bag.Close();
                MessageBox.Show("Veri Silinemedi");
                if (HataYakala == true)
                {
                    MessageBox.Show(kmt.CommandText);
                }
            }
            kmt.Dispose();
        }
        public void kayitGuncelle(string tabloAdi, string alanAdi, object deger, params object[] liste)//kayıt güncelleme metodu
        {
            //// parametre listeli sorgu oluşturuyor
            string ekleSorgu = "UPDATE " + tabloAdi + " SET ";
            ArrayList KolonAdlariListGelen;
            SqlCommand kmt = new SqlCommand();
            bag.Open();

            ////alan adları alınıyor        
            SqlDataAdapter da = new SqlDataAdapter("SELECT * FROM " + tabloAdi, bag);
            DataTable dt2 = new DataTable();
            da.Fill(dt2);
            KolonAdlariListGelen = new ArrayList();
            //array list içeirisine alan adlarını aktarıyoruz

            for (int i = 1; i < dt2.Columns.Count; i++)
            {
                DataColumn dr = dt2.Columns[i];
                KolonAdlariListGelen.Add(dr.ToString());
            }
            //alanadlarını array liste e ekleme işlemi bitti
            for (int i = 0; i < KolonAdlariListGelen.Count; i++)
            {
                if (i != KolonAdlariListGelen.Count - 1)
                {
                    if (liste[i] is string)
                    {
                        if (liste[i] == null)
                            liste[i] = "";
                        kmt.Parameters.Add("@" + KolonAdlariListGelen[i].ToString(), liste[i].ToString());
                        ekleSorgu = ekleSorgu + KolonAdlariListGelen[i].ToString() + "=" + "@" + KolonAdlariListGelen[i] + ",";
                    }
                    else if (liste[i] is int)
                    {
                        if (liste[i] == null)
                            liste[i] = 0;
                        kmt.Parameters.Add("@" + KolonAdlariListGelen[i].ToString(), liste[i].ToString());
                        ekleSorgu = ekleSorgu + KolonAdlariListGelen[i].ToString() + "=" + "@" + KolonAdlariListGelen[i] + ",";
                    }
                }
                else
                {
                    if (liste[i] is string)
                    {
                        if (liste[i] == null)
                            liste[i] = "";
                        kmt.Parameters.Add("@" + KolonAdlariListGelen[i].ToString(), liste[i].ToString());
                        ekleSorgu = ekleSorgu + KolonAdlariListGelen[i].ToString() + "=" + "@" + KolonAdlariListGelen[i];
                    }
                    else if (liste[i] is int)
                    {
                        if (liste[i] == null)
                            liste[i] = 0;
                        kmt.Parameters.Add("@" + KolonAdlariListGelen[i].ToString(), liste[i].ToString());
                        ekleSorgu = ekleSorgu + KolonAdlariListGelen[i].ToString() + "=" + "@" + KolonAdlariListGelen[i];
                    }
                }

            }
            ekleSorgu = ekleSorgu + " WHERE " + alanAdi + "= '" + deger + "'";
            ///////////////////sorgu oluşturuldu
            if (HataYakala==true)
            {
                MessageBox.Show(ekleSorgu);
            }
            
            kmt.Connection = bag;
            kmt.CommandText = ekleSorgu;
            if (HataYakala==true)
            {
                MessageBox.Show("Sql Sorgusu = "+ekleSorgu);
            }
            if (kmt.ExecuteNonQuery() == 1)
            {
                bag.Close();
                MessageBox.Show("Güncelleme Başarılı");
            }
            else
            {
                bag.Close();
                MessageBox.Show("Güncelleme Başarısız");
                if (HataYakala == true)
                {
                    MessageBox.Show(kmt.CommandText);
                }
            }
            kmt.Dispose();
            bag.Close();
        }
        public bool sorguGonder(string sorgu)
        {
            try
            {
                bag.Open();
                SqlCommand kmt = new SqlCommand();
                kmt.Connection = bag;
                kmt.CommandText = sorgu;
                //MessageBox.Show(sorgu.ToString());
                if (kmt.ExecuteNonQuery() == 1)
                {
                    kmt.Dispose();
                    return false;
                }
                else
                {
                    kmt.Dispose();
                    return true;
                }
            }
            catch (Exception e)
            {
                return false;
                if (HataYakala == true)
                {
                    MessageBox.Show(e.Message);
                }
            }
            bag.Close();
        }
    }
}
