﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace arackiralama
{
    public partial class home : UserControl
    {
        public home()
        {
            InitializeComponent();
            homePage hp = new homePage();
            showControl(hp);
        }
        public void showControl(Control control)
        {
            home_Content.Controls.Clear();
            control.Dock = DockStyle.Fill;
            control.BringToFront();
            control.Focus();
            home_Content.Controls.Add(control);
        }
        vtClass vt = new vtClass(false);
        private void btn_home_Click(object sender, EventArgs e)
        {
            homePage hp = new homePage();
            showControl(hp);
        }

        private void btn_carsUsing_Click(object sender, EventArgs e)
        {
            fullList fL = new fullList(vt.verial("araclar.aracPlaka,modeller.modelAd,araclar.aracYil,yakıttip.yakıttipAd,vites.vitesAd,araclar.aracKm,cekis.cekisAd,araclar.aracKisi,renk.renkAd,araclar.aracKlima,iller.ilAd,araclar.aracKiraUcret", "araclar", "INNER JOIN modeller ON modeller.modelID=araclar.modelID INNER JOIN yakıttip ON yakıttip.yakıttipID=araclar.yakıttipID INNER JOIN vites ON vites.vitesID=araclar.vitesID INNER JOIN cekis ON cekis.cekisID=araclar.cekisID INNER JOIN renk ON renk.renkID=araclar.renkID INNER JOIN iller ON iller.ilID=araclar.ilID","aracKiraDurum='1'"));
            showControl(fL);
        }

        private void btn_carsGive_Click(object sender, EventArgs e)
        {
            aracKirala aK = new aracKirala();
            showControl(aK);
        }

        private void btn_araclarList_Click(object sender, EventArgs e)
        {
            fullList fL = new fullList(vt.verial("araclar.aracPlaka,modeller.modelAd,araclar.aracYil,yakıttip.yakıttipAd,vites.vitesAd,araclar.aracKm,cekis.cekisAd,araclar.aracKisi,renk.renkAd,araclar.aracKlima,iller.ilAd,araclar.aracKiraUcret", "araclar", "INNER JOIN modeller ON modeller.modelID=araclar.modelID INNER JOIN yakıttip ON yakıttip.yakıttipID=araclar.yakıttipID INNER JOIN vites ON vites.vitesID=araclar.vitesID INNER JOIN cekis ON cekis.cekisID=araclar.cekisID INNER JOIN renk ON renk.renkID=araclar.renkID INNER JOIN iller ON iller.ilID=araclar.ilID", "0"));
            showControl(fL);
        }

        private void bttn_musteriList_Click(object sender, EventArgs e)
        {
            fullList fL = new fullList(vt.verial("musteriAd,musteriSoyad,musteriCinsiyet,musteriDogumTarihi,musteriAdres,musteriMail,musteriPhone,musteriEhliyetNo,musteriEhliyetTur", "musteriler", "0", "0"));
            showControl(fL);
        }
    }
}
