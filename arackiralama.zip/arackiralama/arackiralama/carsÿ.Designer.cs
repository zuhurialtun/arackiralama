﻿namespace arackiralama
{
    partial class carsİ
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea1 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend1 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series1 = new System.Windows.Forms.DataVisualization.Charting.Series();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.lbl_carsDay = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.lbl_carsCount = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.lbl_carsKiraT = new System.Windows.Forms.Label();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.lbl_carsKiraF = new System.Windows.Forms.Label();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.lbl_carsMonth = new System.Windows.Forms.Label();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.lbl_carsYear = new System.Windows.Forms.Label();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.lbl_carsLast = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.cars_grafik = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.groupBox7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.cars_grafik)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(245)))), ((int)(((byte)(203)))), ((int)(((byte)(92)))));
            this.groupBox1.Controls.Add(this.lbl_carsDay);
            this.groupBox1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.groupBox1.Location = new System.Drawing.Point(3, 3);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(220, 130);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Günlük Kazanç";
            // 
            // lbl_carsDay
            // 
            this.lbl_carsDay.Location = new System.Drawing.Point(6, 20);
            this.lbl_carsDay.Name = "lbl_carsDay";
            this.lbl_carsDay.Size = new System.Drawing.Size(208, 107);
            this.lbl_carsDay.TabIndex = 0;
            this.lbl_carsDay.Text = "0";
            this.lbl_carsDay.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(245)))), ((int)(((byte)(203)))), ((int)(((byte)(92)))));
            this.groupBox2.Controls.Add(this.lbl_carsCount);
            this.groupBox2.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.groupBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.groupBox2.Location = new System.Drawing.Point(239, 3);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(220, 130);
            this.groupBox2.TabIndex = 2;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Toplam Araç Sayısı";
            // 
            // lbl_carsCount
            // 
            this.lbl_carsCount.Location = new System.Drawing.Point(6, 20);
            this.lbl_carsCount.Name = "lbl_carsCount";
            this.lbl_carsCount.Size = new System.Drawing.Size(208, 107);
            this.lbl_carsCount.TabIndex = 0;
            this.lbl_carsCount.Text = "0";
            this.lbl_carsCount.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // groupBox3
            // 
            this.groupBox3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(245)))), ((int)(((byte)(203)))), ((int)(((byte)(92)))));
            this.groupBox3.Controls.Add(this.lbl_carsKiraT);
            this.groupBox3.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.groupBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.groupBox3.Location = new System.Drawing.Point(239, 149);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(220, 130);
            this.groupBox3.TabIndex = 1;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Kirada Olan Araç Sayısı";
            // 
            // lbl_carsKiraT
            // 
            this.lbl_carsKiraT.Location = new System.Drawing.Point(6, 20);
            this.lbl_carsKiraT.Name = "lbl_carsKiraT";
            this.lbl_carsKiraT.Size = new System.Drawing.Size(208, 107);
            this.lbl_carsKiraT.TabIndex = 0;
            this.lbl_carsKiraT.Text = "0";
            this.lbl_carsKiraT.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // groupBox4
            // 
            this.groupBox4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(245)))), ((int)(((byte)(203)))), ((int)(((byte)(92)))));
            this.groupBox4.Controls.Add(this.lbl_carsKiraF);
            this.groupBox4.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.groupBox4.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.groupBox4.Location = new System.Drawing.Point(239, 295);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(220, 130);
            this.groupBox4.TabIndex = 1;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Kirada Olmayan Araç Sayısı";
            // 
            // lbl_carsKiraF
            // 
            this.lbl_carsKiraF.Location = new System.Drawing.Point(6, 20);
            this.lbl_carsKiraF.Name = "lbl_carsKiraF";
            this.lbl_carsKiraF.Size = new System.Drawing.Size(208, 107);
            this.lbl_carsKiraF.TabIndex = 0;
            this.lbl_carsKiraF.Text = "0";
            this.lbl_carsKiraF.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // groupBox5
            // 
            this.groupBox5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(245)))), ((int)(((byte)(203)))), ((int)(((byte)(92)))));
            this.groupBox5.Controls.Add(this.lbl_carsMonth);
            this.groupBox5.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.groupBox5.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.groupBox5.Location = new System.Drawing.Point(3, 149);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(220, 130);
            this.groupBox5.TabIndex = 3;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Aylık Kazanç";
            // 
            // lbl_carsMonth
            // 
            this.lbl_carsMonth.Location = new System.Drawing.Point(6, 20);
            this.lbl_carsMonth.Name = "lbl_carsMonth";
            this.lbl_carsMonth.Size = new System.Drawing.Size(208, 107);
            this.lbl_carsMonth.TabIndex = 0;
            this.lbl_carsMonth.Text = "0";
            this.lbl_carsMonth.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // groupBox6
            // 
            this.groupBox6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(245)))), ((int)(((byte)(203)))), ((int)(((byte)(92)))));
            this.groupBox6.Controls.Add(this.lbl_carsYear);
            this.groupBox6.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.groupBox6.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.groupBox6.Location = new System.Drawing.Point(3, 295);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(220, 130);
            this.groupBox6.TabIndex = 1;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Yıllık Kazanç";
            // 
            // lbl_carsYear
            // 
            this.lbl_carsYear.Location = new System.Drawing.Point(6, 20);
            this.lbl_carsYear.Name = "lbl_carsYear";
            this.lbl_carsYear.Size = new System.Drawing.Size(208, 107);
            this.lbl_carsYear.TabIndex = 0;
            this.lbl_carsYear.Text = "0";
            this.lbl_carsYear.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // groupBox7
            // 
            this.groupBox7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(245)))), ((int)(((byte)(203)))), ((int)(((byte)(92)))));
            this.groupBox7.Controls.Add(this.lbl_carsLast);
            this.groupBox7.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.groupBox7.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.groupBox7.Location = new System.Drawing.Point(3, 435);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(456, 80);
            this.groupBox7.TabIndex = 2;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "Kiralanan Son Araç";
            // 
            // lbl_carsLast
            // 
            this.lbl_carsLast.Location = new System.Drawing.Point(6, 20);
            this.lbl_carsLast.Name = "lbl_carsLast";
            this.lbl_carsLast.Size = new System.Drawing.Size(444, 57);
            this.lbl_carsLast.TabIndex = 0;
            this.lbl_carsLast.Text = "0";
            this.lbl_carsLast.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Interval = 1500;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // cars_grafik
            // 
            this.cars_grafik.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            chartArea1.Name = "ChartArea1";
            this.cars_grafik.ChartAreas.Add(chartArea1);
            legend1.Name = "Legend1";
            this.cars_grafik.Legends.Add(legend1);
            this.cars_grafik.Location = new System.Drawing.Point(475, 3);
            this.cars_grafik.Name = "cars_grafik";
            series1.ChartArea = "ChartArea1";
            series1.Legend = "Legend1";
            series1.Name = "Series1";
            this.cars_grafik.Series.Add(series1);
            this.cars_grafik.Size = new System.Drawing.Size(586, 525);
            this.cars_grafik.TabIndex = 4;
            this.cars_grafik.Tag = "Marka Model İstatistiği";
            this.cars_grafik.Text = "Marka Model İstatistiği";
            // 
            // carsİ
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(237)))), ((int)(((byte)(223)))));
            this.Controls.Add(this.cars_grafik);
            this.Controls.Add(this.groupBox7);
            this.Controls.Add(this.groupBox6);
            this.Controls.Add(this.groupBox5);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Name = "carsİ";
            this.Size = new System.Drawing.Size(1064, 531);
            this.groupBox1.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.groupBox4.ResumeLayout(false);
            this.groupBox5.ResumeLayout(false);
            this.groupBox6.ResumeLayout(false);
            this.groupBox7.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.cars_grafik)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label lbl_carsDay;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label lbl_carsCount;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label lbl_carsKiraT;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Label lbl_carsKiraF;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Label lbl_carsMonth;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.Label lbl_carsYear;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.Label lbl_carsLast;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.DataVisualization.Charting.Chart cars_grafik;
    }
}
