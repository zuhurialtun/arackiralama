﻿namespace arackiralama
{
    partial class userDelete
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_userDelete = new System.Windows.Forms.Button();
            this.cb_musteriTc = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btn_userDelete
            // 
            this.btn_userDelete.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(207)))), ((int)(((byte)(219)))), ((int)(((byte)(213)))));
            this.btn_userDelete.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_userDelete.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(36)))), ((int)(((byte)(35)))));
            this.btn_userDelete.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_userDelete.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btn_userDelete.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(36)))), ((int)(((byte)(35)))));
            this.btn_userDelete.Location = new System.Drawing.Point(29, 46);
            this.btn_userDelete.Name = "btn_userDelete";
            this.btn_userDelete.Size = new System.Drawing.Size(273, 50);
            this.btn_userDelete.TabIndex = 34;
            this.btn_userDelete.Text = "Sil";
            this.btn_userDelete.UseVisualStyleBackColor = false;
            this.btn_userDelete.Click += new System.EventHandler(this.btn_userDelete_Click);
            // 
            // cb_musteriTc
            // 
            this.cb_musteriTc.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(36)))), ((int)(((byte)(35)))));
            this.cb_musteriTc.FormattingEnabled = true;
            this.cb_musteriTc.Location = new System.Drawing.Point(92, 19);
            this.cb_musteriTc.Name = "cb_musteriTc";
            this.cb_musteriTc.Size = new System.Drawing.Size(210, 21);
            this.cb_musteriTc.TabIndex = 33;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(36)))), ((int)(((byte)(35)))));
            this.label4.Location = new System.Drawing.Point(26, 20);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(60, 16);
            this.label4.TabIndex = 32;
            this.label4.Text = "TC No :";
            // 
            // userDelete
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(237)))), ((int)(((byte)(223)))));
            this.Controls.Add(this.btn_userDelete);
            this.Controls.Add(this.cb_musteriTc);
            this.Controls.Add(this.label4);
            this.Name = "userDelete";
            this.Size = new System.Drawing.Size(664, 531);
            this.Load += new System.EventHandler(this.userDelete_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_userDelete;
        private System.Windows.Forms.ComboBox cb_musteriTc;
        private System.Windows.Forms.Label label4;
    }
}
