﻿namespace arackiralama
{
    partial class sigorta
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.data_sigorta = new System.Windows.Forms.DataGridView();
            this.btn_sigortaAdd = new System.Windows.Forms.Button();
            this.rtb_sigortaBilgi = new System.Windows.Forms.RichTextBox();
            this.tb_sigortaAd = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.tb_sigortaUcret = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.cb_sigorta = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.btn_sigortaDelete = new System.Windows.Forms.Button();
            this.btn_sigortaUpdate = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.data_sigorta)).BeginInit();
            this.SuspendLayout();
            // 
            // data_sigorta
            // 
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.data_sigorta.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.data_sigorta.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.DisplayedCells;
            this.data_sigorta.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(237)))), ((int)(((byte)(223)))));
            this.data_sigorta.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.data_sigorta.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(245)))), ((int)(((byte)(203)))), ((int)(((byte)(92)))));
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(36)))), ((int)(((byte)(35)))));
            dataGridViewCellStyle2.Padding = new System.Windows.Forms.Padding(1, 2, 0, 1);
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(237)))), ((int)(((byte)(223)))));
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(36)))), ((int)(((byte)(35)))));
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.data_sigorta.DefaultCellStyle = dataGridViewCellStyle2;
            this.data_sigorta.Location = new System.Drawing.Point(3, 34);
            this.data_sigorta.Name = "data_sigorta";
            this.data_sigorta.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect;
            this.data_sigorta.Size = new System.Drawing.Size(1030, 198);
            this.data_sigorta.TabIndex = 7;
            this.data_sigorta.CellMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.data_sigorta_CellMouseClick);
            // 
            // btn_sigortaAdd
            // 
            this.btn_sigortaAdd.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(207)))), ((int)(((byte)(219)))), ((int)(((byte)(213)))));
            this.btn_sigortaAdd.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_sigortaAdd.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(36)))), ((int)(((byte)(35)))));
            this.btn_sigortaAdd.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_sigortaAdd.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btn_sigortaAdd.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(36)))), ((int)(((byte)(35)))));
            this.btn_sigortaAdd.Location = new System.Drawing.Point(32, 457);
            this.btn_sigortaAdd.Name = "btn_sigortaAdd";
            this.btn_sigortaAdd.Size = new System.Drawing.Size(268, 50);
            this.btn_sigortaAdd.TabIndex = 35;
            this.btn_sigortaAdd.Text = "Sigortayı Kaydet";
            this.btn_sigortaAdd.UseVisualStyleBackColor = false;
            this.btn_sigortaAdd.Click += new System.EventHandler(this.btn_sigortaAdd_Click);
            // 
            // rtb_sigortaBilgi
            // 
            this.rtb_sigortaBilgi.Location = new System.Drawing.Point(32, 338);
            this.rtb_sigortaBilgi.MaxLength = 1500;
            this.rtb_sigortaBilgi.Name = "rtb_sigortaBilgi";
            this.rtb_sigortaBilgi.Size = new System.Drawing.Size(564, 113);
            this.rtb_sigortaBilgi.TabIndex = 34;
            this.rtb_sigortaBilgi.Text = "";
            // 
            // tb_sigortaAd
            // 
            this.tb_sigortaAd.Location = new System.Drawing.Point(146, 290);
            this.tb_sigortaAd.MaxLength = 80;
            this.tb_sigortaAd.Name = "tb_sigortaAd";
            this.tb_sigortaAd.Size = new System.Drawing.Size(154, 20);
            this.tb_sigortaAd.TabIndex = 33;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label12.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(36)))), ((int)(((byte)(35)))));
            this.label12.Location = new System.Drawing.Point(29, 313);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(146, 16);
            this.label12.TabIndex = 32;
            this.label12.Text = "Sigorta Açıklaması :";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(36)))), ((int)(((byte)(35)))));
            this.label1.Location = new System.Drawing.Point(29, 290);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(93, 16);
            this.label1.TabIndex = 31;
            this.label1.Text = "Sigorta Adı :";
            // 
            // tb_sigortaUcret
            // 
            this.tb_sigortaUcret.Location = new System.Drawing.Point(442, 294);
            this.tb_sigortaUcret.MaxLength = 5;
            this.tb_sigortaUcret.Name = "tb_sigortaUcret";
            this.tb_sigortaUcret.Size = new System.Drawing.Size(154, 20);
            this.tb_sigortaUcret.TabIndex = 37;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(36)))), ((int)(((byte)(35)))));
            this.label2.Location = new System.Drawing.Point(325, 294);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(111, 16);
            this.label2.TabIndex = 36;
            this.label2.Text = "Sigorta Ücreti :";
            // 
            // cb_sigorta
            // 
            this.cb_sigorta.FormattingEnabled = true;
            this.cb_sigorta.Location = new System.Drawing.Point(738, 296);
            this.cb_sigorta.Name = "cb_sigorta";
            this.cb_sigorta.Size = new System.Drawing.Size(145, 21);
            this.cb_sigorta.TabIndex = 39;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(36)))), ((int)(((byte)(35)))));
            this.label7.Location = new System.Drawing.Point(639, 298);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(93, 16);
            this.label7.TabIndex = 38;
            this.label7.Text = "Sigorta Adı :";
            // 
            // btn_sigortaDelete
            // 
            this.btn_sigortaDelete.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(207)))), ((int)(((byte)(219)))), ((int)(((byte)(213)))));
            this.btn_sigortaDelete.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_sigortaDelete.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(36)))), ((int)(((byte)(35)))));
            this.btn_sigortaDelete.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_sigortaDelete.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btn_sigortaDelete.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(36)))), ((int)(((byte)(35)))));
            this.btn_sigortaDelete.Location = new System.Drawing.Point(642, 323);
            this.btn_sigortaDelete.Name = "btn_sigortaDelete";
            this.btn_sigortaDelete.Size = new System.Drawing.Size(241, 50);
            this.btn_sigortaDelete.TabIndex = 40;
            this.btn_sigortaDelete.Text = "Sigortayı Sil";
            this.btn_sigortaDelete.UseVisualStyleBackColor = false;
            this.btn_sigortaDelete.Click += new System.EventHandler(this.btn_sigortaDelete_Click);
            // 
            // btn_sigortaUpdate
            // 
            this.btn_sigortaUpdate.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(207)))), ((int)(((byte)(219)))), ((int)(((byte)(213)))));
            this.btn_sigortaUpdate.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_sigortaUpdate.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(36)))), ((int)(((byte)(35)))));
            this.btn_sigortaUpdate.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_sigortaUpdate.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btn_sigortaUpdate.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(36)))), ((int)(((byte)(35)))));
            this.btn_sigortaUpdate.Location = new System.Drawing.Point(328, 457);
            this.btn_sigortaUpdate.Name = "btn_sigortaUpdate";
            this.btn_sigortaUpdate.Size = new System.Drawing.Size(268, 50);
            this.btn_sigortaUpdate.TabIndex = 41;
            this.btn_sigortaUpdate.Text = "Sigorta Bilgilerini Güncelle";
            this.btn_sigortaUpdate.UseVisualStyleBackColor = false;
            this.btn_sigortaUpdate.Click += new System.EventHandler(this.btn_sigortaUpdate_Click);
            // 
            // sigorta
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(237)))), ((int)(((byte)(223)))));
            this.Controls.Add(this.btn_sigortaUpdate);
            this.Controls.Add(this.btn_sigortaDelete);
            this.Controls.Add(this.cb_sigorta);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.tb_sigortaUcret);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.btn_sigortaAdd);
            this.Controls.Add(this.rtb_sigortaBilgi);
            this.Controls.Add(this.tb_sigortaAd);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.data_sigorta);
            this.Name = "sigorta";
            this.Size = new System.Drawing.Size(1064, 531);
            this.Load += new System.EventHandler(this.sigorta_Load);
            ((System.ComponentModel.ISupportInitialize)(this.data_sigorta)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView data_sigorta;
        private System.Windows.Forms.Button btn_sigortaAdd;
        private System.Windows.Forms.RichTextBox rtb_sigortaBilgi;
        private System.Windows.Forms.TextBox tb_sigortaAd;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox tb_sigortaUcret;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox cb_sigorta;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button btn_sigortaDelete;
        private System.Windows.Forms.Button btn_sigortaUpdate;
    }
}
